# Cutline

A lightweight Rust replay clipper for Windows with configurable capture, high-quality audio and video, a built-in editor, and optional sound and overlay notifications.

## Features

- Keep the last 5–600 seconds of your primary display in an in-memory replay buffer.
- Save a clip with a configurable global shortcut.
- Choose native resolution or presets from 480p to 2160p, with 30 or 60 FPS targets.
- Choose H.264 video quality and 24-bit stereo capture with lossless ALAC or AAC export.
- Select playback and microphone devices independently.
- Browse, preview, trim and delete local clips.
- Enable or disable the clip-saved sound and overlay independently.
- Run in the Windows system tray. No account is required.

## Requirements

- Windows 10/11, 64-bit.
- A recent stable Rust toolchain with the `x86_64-pc-windows-msvc` target.
- Visual Studio Build Tools with **Desktop development with C++** and a Windows SDK.
- FFmpeg for recording, previews, editing and media integration tests.

The source repository does not include FFmpeg or compiled application files. You can compile and open the UI without FFmpeg; install it before using media features.

## Build and run

```powershell
rustup update stable
# Supply your local FFmpeg executable; see the next section.
.\scripts\setup-ffmpeg.ps1 -FFmpegPath 'C:\path\to\ffmpeg.exe'
cargo build --release --locked
.\target\release\cutline.exe
```

FFmpeg 9.0.2 full build from [Gyan's Windows builds](https://www.gyan.dev/ffmpeg/builds/) was used for the original validation. Use a build supporting `gdigrab`, H.264/libx264, AAC, ALAC and the usual video/audio filters. The helper copies the executable you provide into `media/`; it does not download anything or change encoding settings.

To make a portable copy, place these files together:

```text
Cutline.exe
media/
  ffmpeg.exe
  COPYING.txt
  NOTICE.txt
```

The app's icon and save sound are embedded in its executable. Publish a portable ZIP as a **GitHub Release asset**, keeping build outputs and executables out of the source repository.

## Quality and performance

Maximum video quality uses H.264 CRF 12; High uses CRF 15; Compact uses CRF 23. Edited video uses CRF 12. Lossless ALAC avoids lossy audio compression; AAC at 320 kbit/s is available for sharing compatibility.

Frame rates are targets, not guarantees. CPU capture, display size and other workloads affect performance. A short 2560×1440 desktop test delivered about 34 FPS with a 60 FPS target. Sustained in-game performance has not been established. Try 30 FPS or a lower resolution if needed.

The video replay ring is limited to 1000 MB. Higher quality can fill it before the chosen duration. Audio, previews and an outstanding clip snapshot use additional memory. Captured video remains in memory until you request a save.

The confirmation overlay appears for 2.5 seconds, leaves keyboard focus unchanged and works while the main UI is in the tray. Exclusive-fullscreen games may cover ordinary overlay windows.

## Development checks

```powershell
cargo fmt --all -- --check
cargo clippy --release --locked --all-targets -- -D warnings
cargo test --release --locked -- --test-threads=1
```

The full tests require FFmpeg and an interactive Windows desktop for native overlay, hotkey and tray checks. Run them sequentially to avoid interference between window tests. Fourteen tests passed during the original validation.

Preferences are stored under `%LOCALAPPDATA%\Cutline\preferences.json`; clips default to `%USERPROFILE%\Videos\Cutline`. These local files do not belong in the repository.

## License

Cutline's code and included original assets are licensed under **GPL-3.0-or-later**. See [LICENSE](LICENSE). If you distribute a modified version, comply with the GPL's corresponding-source requirements. Private modifications do not have to be published.

Third-party dependencies keep their own licenses. FFmpeg is a separate program and is not included in this source archive. See [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) before distributing a portable binary package.
