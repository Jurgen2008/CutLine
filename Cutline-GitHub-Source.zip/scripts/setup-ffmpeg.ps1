[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$FFmpegPath
)

$ErrorActionPreference = 'Stop'
$repoRoot = Split-Path -Parent $PSScriptRoot
$source = (Resolve-Path -LiteralPath $FFmpegPath).Path
if (-not (Test-Path -LiteralPath $source -PathType Leaf)) {
    throw 'FFmpegPath must point to an ffmpeg.exe file.'
}
if ([IO.Path]::GetFileName($source) -ine 'ffmpeg.exe') {
    throw 'Select the ffmpeg.exe executable from your FFmpeg build.'
}
$destination = Join-Path $repoRoot 'media\ffmpeg.exe'
if (-not [string]::Equals($source, $destination, [StringComparison]::OrdinalIgnoreCase)) {
    Copy-Item -LiteralPath $source -Destination $destination -Force
}
Write-Output "FFmpeg copied to $destination"
Write-Output 'You can now run: cargo build --release --locked'
Write-Output 'Before distributing FFmpeg, retain its notices and provide its corresponding source.'
