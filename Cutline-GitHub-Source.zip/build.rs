use std::{
    env, fs,
    path::{Path, PathBuf},
};

fn main() {
    let out = PathBuf::from(env::var_os("OUT_DIR").unwrap());
    let target = env::var("TARGET").unwrap();
    if target.ends_with("windows-msvc") {
        println!("cargo:rerun-if-changed=media/cutline.ico");
        println!("cargo:rerun-if-changed=cutline.rc");
        let resource = out.join("cutline.res");
        let mut rc = find_msvc_tools::find(&target, "rc.exe")
            .unwrap_or_else(|| std::process::Command::new("rc.exe"));
        let status = rc
            .args(["/nologo", "/fo"])
            .arg(&resource)
            .arg("cutline.rc")
            .status()
            .expect("Windows SDK resource compiler is required");
        assert!(status.success(), "Failed to compile the Cutline icon");
        println!("cargo:rustc-link-arg-bin=cutline={}", resource.display());
    }
    let dest = out.ancestors().nth(3).unwrap().join("media");
    fs::create_dir_all(&dest).unwrap();
    for name in ["ffmpeg.exe", "COPYING.txt", "NOTICE.txt"] {
        let source = Path::new("media").join(name);
        println!("cargo:rerun-if-changed={}", source.display());
        if !source.is_file() {
            if name == "ffmpeg.exe" {
                println!(
                    "cargo:warning=FFmpeg is not installed. Run scripts/setup-ffmpeg.ps1 before using recording, editing or previews."
                );
            }
            continue;
        }
        let copy = dest.join(name);
        if copy.exists() {
            fs::remove_file(&copy).unwrap();
        }
        fs::hard_link(&source, &copy)
            .or_else(|_| fs::copy(&source, &copy).map(|_| ()))
            .unwrap();
    }
}
