use crate::{
    audio::Source,
    design::*,
    desktop::{self, Shortcut},
    editor::{Editor, Outcome},
    library::{Item, Library},
    preview::Previews,
    replay::{self, Engine, Runtime, State},
    settings::{AudioQuality, HEIGHTS, KEYS, Settings, VideoQuality, resolution},
};
use eframe::egui::*;
use std::{
    cell::RefCell,
    fs,
    path::PathBuf,
    rc::Rc,
    time::{Duration, Instant},
};

#[derive(Clone, Copy, PartialEq)]
enum Page {
    Console,
    Library,
    Settings,
}

pub struct Window {
    engine: Engine,
    settings: Settings,
    shortcut: Option<Shortcut>,
    key_error: Option<String>,
    page: Page,
    library: Library,
    repaint: Context,
    previews: Previews,
    editor: Rc<RefCell<Option<Editor>>>,
    delete_target: Option<PathBuf>,
    playback_devices: Vec<(String, String)>,
    microphones: Vec<(String, String)>,

    last_scan: Instant,
    last_saves: u64,
    shot: Option<PathBuf>,
    frames: u32,
}
impl Window {
    pub fn new(shot: Option<PathBuf>) -> Self {
        let settings = Settings::load();
        crate::overlay::set_enabled(settings.save_overlay);
        let engine = Runtime::new(settings.clone());
        Self {
            settings,
            engine,
            shortcut: None,
            key_error: None,
            page: Page::Console,
            library: Library::default(),
            repaint: Context::default(),
            previews: Previews::default(),
            editor: Rc::default(),
            delete_target: None,
            playback_devices: Vec::new(),
            microphones: Vec::new(),

            last_scan: Instant::now(),
            last_saves: 0,
            shot,
            frames: 0,
        }
    }
    pub fn start_replay(&mut self, ctx: &Context) {
        if self.settings.armed {
            self.enable(ctx);
        }
    }
    pub fn open(&mut self, cc: &eframe::CreationContext<'_>, from_tray: bool) {
        setup(&cc.egui_ctx);
        if self.shot.is_none() {
            let editor = self.editor.clone();
            if let Err(e) = crate::tray::on_minimize(cc, move || {
                editor.borrow_mut().take();
            }) {
                self.message(format!("Could not enable minimize to tray · {e}"));
            }
        }
        self.repaint = cc.egui_ctx.clone();
        self.scan();
        if from_tray && self.settings.armed {
            self.bind(&cc.egui_ctx);
        } else {
            self.start_replay(&cc.egui_ctx);
        }
    }
    fn scan(&mut self) {
        self.last_scan = Instant::now();
        self.library
            .refresh(self.settings.folder.clone(), &self.repaint);
    }
    fn persist(&mut self) {
        self.engine.lock().unwrap().configure(self.settings.clone());
        if let Err(e) = self.settings.save() {
            self.message(format!("Preferences could not be saved · {e}"));
        }
    }
    pub fn message(&self, s: String) {
        self.engine.lock().unwrap().notice = s;
    }
    fn bind(&mut self, ctx: &Context) {
        self.shortcut = None;
        self.key_error = None;
        if self.shot.is_some() {
            return;
        }
        match Shortcut::bind(self.settings.key, self.engine.clone(), ctx.clone()) {
            Ok(s) => self.shortcut = Some(s),
            Err(e) => self.key_error = Some(e),
        }
    }
    fn enable(&mut self, ctx: &Context) {
        self.bind(ctx);
        replay::start(&self.engine);
    }
    fn toggle(&mut self, ctx: &Context, state: &State) {
        if matches!(state, State::Live(_) | State::Starting) {
            self.settings.armed = false;
            self.shortcut = None;
            self.key_error = None;
            let mut r = self.engine.lock().unwrap();
            r.stop();
            r.notice.clear();
            drop(r);
        } else {
            self.settings.armed = true;
            self.enable(ctx);
        }
        self.persist();
    }
    fn goto(&mut self, p: Page) {
        if self.page == Page::Library && p != Page::Library {
            self.previews = Previews::default();
        }
        self.page = p;
        if p == Page::Library {
            self.scan();
        }
        if p == Page::Settings {
            self.playback_devices = Source::Playback.devices();
            self.microphones = Source::Microphone.devices();
        }
    }
    fn sidebar(&mut self, ctx: &Context) {
        SidePanel::left("navigation")
            .show_separator_line(false)
            .exact_width(186.)
            .resizable(false)
            .frame(Frame::NONE.fill(NAV))
            .show(ctx, |ui| {
                let r = ui.max_rect();
                let p = ui.painter().clone();
                line(&p, r.right_top(), r.right_bottom(), EDGE, 1.);
                mark(
                    &p,
                    Rect::from_min_size(r.min + vec2(19., 23.), vec2(32., 32.)),
                );
                write(
                    &p,
                    r.min + vec2(61., 38.),
                    Align2::LEFT_CENTER,
                    "Cutline",
                    display(29.),
                    INK,
                );
                small(&p, r.min + vec2(20., 105.), "WORKSPACE");
                for (i, (page, name, symbol)) in [
                    (Page::Console, "Replay console", "console"),
                    (Page::Library, "Clip library", "film"),
                    (Page::Settings, "Settings", "settings"),
                ]
                .into_iter()
                .enumerate()
                {
                    let rr = Rect::from_min_size(
                        r.min + vec2(10., 125. + 43. * i as f32),
                        vec2(r.width() - 21., 38.),
                    );
                    let res = interact(ui, name, rr);
                    let selected = self.page == page;
                    if selected || res.hovered() {
                        p.rect_filled(rr, 6, if selected { SLATE } else { PANEL });
                    }
                    if selected {
                        p.rect_filled(
                            Rect::from_center_size(
                                pos2(rr.left() + 1., rr.center().y),
                                vec2(2., 18.),
                            ),
                            2,
                            GRAPHITE,
                        );
                    }
                    let color = if selected { GRAPHITE } else { MUTED };
                    icon(&p, pos2(rr.left() + 20., rr.center().y), symbol, 17., color);
                    write(
                        &p,
                        pos2(rr.left() + 38., rr.center().y - 1.),
                        Align2::LEFT_CENTER,
                        name,
                        if selected {
                            bold(14.)
                        } else {
                            FontId::proportional(14.)
                        },
                        color,
                    );
                    if res.clicked() {
                        self.goto(page);
                    }
                }
                let base = r.bottom() - 48.;
                line(
                    &p,
                    pos2(r.left() + 18., base - 27.),
                    pos2(r.right() - 18., base - 27.),
                    EDGE,
                    1.,
                );
                icon(&p, pos2(r.left() + 29., base + 1.), "storage", 20., MUTED);
                write(
                    &p,
                    pos2(r.left() + 49., base - 6.),
                    Align2::LEFT_CENTER,
                    "Local workspace",
                    bold(13.),
                    INK,
                );
                write(
                    &p,
                    pos2(r.left() + 49., base + 12.),
                    Align2::LEFT_CENTER,
                    "On this device",
                    FontId::proportional(12.),
                    MUTED,
                );
            });
    }
    fn heading(&self, ui: &mut Ui, title: &str, subtitle: &str) {
        let (r, _) = ui.allocate_exact_size(vec2(ui.available_width(), 76.), Sense::hover());
        let p = ui.painter();
        write(p, r.min, Align2::LEFT_TOP, title, display(38.), INK);
        write(
            p,
            r.min + vec2(1., 55.),
            Align2::LEFT_CENTER,
            subtitle,
            FontId::proportional(15.),
            MUTED,
        );
    }
    fn hero(&mut self, ui: &mut Ui, state: &State, duration: f64, busy: bool) {
        let (r, _) = ui.allocate_exact_size(vec2(ui.available_width(), 248.), Sense::hover());
        let p = ui.painter().clone();
        let live = matches!(state, State::Live(_));
        let starting = matches!(state, State::Starting);
        let border = OLIVE;
        box_at(&p, r, 8, PANEL, border);
        p.rect_filled(
            r.with_max_y(r.top() + 190.),
            CornerRadius {
                nw: 8,
                ne: 8,
                sw: 0,
                se: 0,
            },
            SILVER,
        );
        let art = Rect::from_min_max(
            pos2(r.left() + r.width() * 0.54, r.top() + 9.),
            r.right_top() + vec2(-8., 159.),
        );
        film_stack(&p, art);
        let x = r.left() + 24.;
        let y = r.top();
        let accent = Rect::from_min_size(pos2(x, y + 25.), vec2(12., 2.));
        p.rect_filled(accent, 1, GRAPHITE);
        write(
            &p,
            pos2(x + 21., y + 26.),
            Align2::LEFT_CENTER,
            "REPLAY BUFFER",
            FontId::monospace(12.),
            GRAPHITE,
        );
        let number = write(
            &p,
            pos2(x - 2., y + 82.),
            Align2::LEFT_CENTER,
            self.settings.seconds,
            FontId::monospace(76.),
            GRAPHITE,
        );
        write(
            &p,
            pos2(number.right() + 10., y + 96.),
            Align2::LEFT_CENTER,
            "seconds",
            display(25.),
            GRAPHITE,
        );
        write(
            &p,
            pos2(x, y + 137.),
            Align2::LEFT_CENTER,
            if live {
                format!(
                    "{:.1}s available to save",
                    duration.min(self.settings.seconds as f64)
                )
            } else {
                "Configured clip length".into()
            },
            FontId::proportional(13.),
            GRAPHITE,
        );
        let rx = r.right() - 24.;
        let span = rx - x;
        let ruler = y + 165.;
        let fraction = (duration / self.settings.seconds as f64).clamp(0., 1.) as f32;
        for i in 0..=72 {
            let f = i as f32 / 72.;
            let height = if i % 6 == 0 { 10. } else { 5. };
            let col = if live && f >= 1. - fraction {
                GRAPHITE
            } else if i % 6 == 0 {
                EDGE
            } else {
                OLIVE
            };
            line(
                &p,
                pos2(x + span * f, ruler - height),
                pos2(x + span * f, ruler),
                col,
                1.,
            );
        }
        write(
            &p,
            pos2(x, ruler + 4.),
            Align2::LEFT_TOP,
            format!(
                "−{:02}:{:02}",
                self.settings.seconds / 60,
                self.settings.seconds % 60
            ),
            FontId::monospace(10.),
            GRAPHITE,
        );
        write(
            &p,
            pos2(rx, ruler + 4.),
            Align2::RIGHT_TOP,
            "NOW",
            FontId::monospace(10.),
            GRAPHITE,
        );
        line(
            &p,
            pos2(r.left() + 1., y + 190.),
            pos2(r.right() - 1., y + 190.),
            border,
            1.,
        );
        let cy = y + 219.;
        let status = match state {
            State::Off => "Buffer paused",
            State::Starting => "Starting capture",
            State::Live(_) => "Buffer active",
            State::Failed(_) => "Capture unavailable",
        };
        p.circle_filled(
            pos2(x + 3., cy),
            3.5,
            if live || starting { SLATE } else { MUTED },
        );
        write(
            &p,
            pos2(x + 16., cy - 1.),
            Align2::LEFT_CENTER,
            status,
            bold(13.),
            INK,
        );
        let primary = Rect::from_center_size(pos2(rx - 74., cy), vec2(148., 34.));
        if live {
            let pause =
                Rect::from_min_size(pos2(primary.left() - 42., primary.top()), vec2(34., 34.));
            let res = interact(ui, "pause", pause).on_hover_text("Pause the replay buffer");
            box_at(&p, pause, 5, if res.hovered() { EDGE } else { PANEL }, EDGE);
            icon(&p, pause.center(), "pause", 17., INK);
            if res.clicked() {
                self.toggle(ui.ctx(), state);
            }
            if button(
                ui,
                "save",
                primary,
                if busy { "Saving…" } else { "Save clip" },
                "save",
                true,
            ) {
                replay::save(&self.engine);
            }
        } else if button(
            ui,
            "enable",
            primary,
            if starting {
                "Cancel"
            } else if matches!(state, State::Failed(_)) {
                "Retry capture"
            } else {
                "Enable buffer"
            },
            "power",
            true,
        ) {
            self.toggle(ui.ctx(), state);
        }
    }
    fn section(ui: &mut Ui, title: &str, link: Option<&str>) -> bool {
        let (r, _) = ui.allocate_exact_size(vec2(ui.available_width(), 38.), Sense::hover());
        write(
            ui.painter(),
            r.left_center(),
            Align2::LEFT_CENTER,
            title,
            display(23.),
            INK,
        );
        if let Some(link) = link {
            let area = Rect::from_min_max(pos2(r.right() - 110., r.top()), r.right_bottom());
            let res = interact(ui, link, area);
            write(
                ui.painter(),
                r.right_center() - vec2(16., 0.),
                Align2::RIGHT_CENTER,
                link,
                FontId::proportional(13.),
                if res.hovered() { SLATE } else { MUTED },
            );
            icon(
                ui.painter(),
                r.right_center() - vec2(5., 0.),
                "chev",
                13.,
                MUTED,
            );
            res.clicked()
        } else {
            false
        }
    }
    fn console(&mut self, ui: &mut Ui, state: &State, duration: f64, busy: bool) {
        self.heading(
            ui,
            "Replay console",
            "Keep a rolling buffer of your display and save a clip with one key.",
        );
        self.hero(ui, state, duration, busy);
        ui.add_space(13.);
        if Self::section(ui, "Capture setup", Some("Edit settings")) {
            self.goto(Page::Settings);
        }
        let (r, _) = ui.allocate_exact_size(vec2(ui.available_width(), 72.), Sense::hover());
        let width = (r.width() - 20.) / 3.;
        let info = [
            (
                "keyboard",
                "Clip shortcut",
                self.settings.key_name().to_owned(),
            ),
            (
                "display",
                "Video format",
                format!(
                    "{}  /  {} FPS",
                    resolution(self.settings.height),
                    self.settings.fps
                ),
            ),
            (
                "audio",
                "Clip audio",
                match (self.settings.sound, self.settings.microphone) {
                    (true, true) => "Playback + mic",
                    (true, false) => "Playback",
                    (false, true) => "Microphone",
                    (false, false) => "Muted",
                }
                .to_owned(),
            ),
        ];
        for (i, (symbol, label, value)) in info.iter().enumerate() {
            let rr =
                Rect::from_min_size(r.min + vec2((width + 10.) * i as f32, 0.), vec2(width, 72.));
            let res = interact(ui, label, rr);
            let p = ui.painter();
            box_at(p, rr, 7, if res.hovered() { EDGE } else { PANEL }, EDGE);
            icon(p, rr.min + vec2(23., 24.), symbol, 17., MUTED);
            write(
                p,
                rr.min + vec2(39., 23.),
                Align2::LEFT_CENTER,
                label,
                FontId::proportional(12.),
                MUTED,
            );
            write(
                p,
                rr.min + vec2(16., 49.),
                Align2::LEFT_CENTER,
                value,
                bold(16.),
                INK,
            );
            if res.clicked() {
                self.goto(Page::Settings);
            }
        }
        ui.add_space(13.);
        if Self::section(ui, "Recent clips", Some("View library")) {
            self.goto(Page::Library);
        }
        self.items(ui, 2);
    }
    fn items(&mut self, ui: &mut Ui, limit: usize) {
        if self.library.files.is_empty() {
            let (r, _) = ui.allocate_exact_size(vec2(ui.available_width(), 81.), Sense::hover());
            let p = ui.painter();
            box_at(p, r, 7, NAV, EDGE);
            let tile = Rect::from_center_size(r.left_center() + vec2(36., 0.), vec2(38., 38.));
            box_at(p, tile, 6, PANEL, EDGE);
            icon(p, tile.center(), "film", 21., MUTED);
            write(
                p,
                r.left_center() + vec2(70., -10.),
                Align2::LEFT_CENTER,
                if self.library.error.is_some() {
                    "Folder unavailable"
                } else {
                    "No clips yet"
                },
                bold(15.),
                INK,
            );
            write(
                p,
                r.left_center() + vec2(70., 12.),
                Align2::LEFT_CENTER,
                self.library
                    .error
                    .clone()
                    .unwrap_or_else(|| "Your saved replays will appear here.".into()),
                FontId::proportional(13.),
                MUTED,
            );
        }
        for f in self.library.files.iter().take(limit) {
            let (r, _) = ui.allocate_exact_size(vec2(ui.available_width(), 62.), Sense::hover());
            let delete = Rect::from_center_size(r.right_center() - vec2(43., 0.), vec2(66., 32.));
            let edit = delete.translate(vec2(-64., 0.)).shrink2(vec2(6., 0.));
            let play = Rect::from_min_max(r.min, pos2(edit.left() - 4., r.bottom()));
            let res = interact(ui, &f.path, play);
            let p = ui.painter();
            box_at(p, r, 6, if res.hovered() { EDGE } else { PANEL }, EDGE);
            icon(p, r.left_center() + vec2(25., 0.), "play", 18., SLATE);
            let title = f.path.file_stem().unwrap_or_default().to_string_lossy();
            let p = p.with_clip_rect(ui.clip_rect().intersect(play.shrink2(vec2(4., 0.))));
            write(
                &p,
                r.left_center() + vec2(45., -10.),
                Align2::LEFT_CENTER,
                title,
                bold(15.),
                INK,
            );
            write(
                &p,
                r.left_center() + vec2(45., 12.),
                Align2::LEFT_CENTER,
                format!("{}   /   {}", f.date, f.size),
                FontId::proportional(12.),
                MUTED,
            );
            if res.clicked()
                && let Err(e) = desktop::open(&f.path)
            {
                self.message(e);
            }
            if ui
                .push_id((&f.path, "edit"), |ui| ui.put(edit, Button::new("Edit")))
                .inner
                .clicked()
            {
                *self.editor.borrow_mut() =
                    Some(Editor::open(f.path.clone(), self.settings.audio_quality));
            }
            if ui.put(delete, Button::new("Delete")).clicked() {
                self.delete_target = Some(f.path.clone());
            }
        }
    }
    fn confirm_delete(&mut self, ctx: &Context) {
        let Some(path) = self.delete_target.clone() else {
            return;
        };
        let modal = Modal::new(Id::new("delete clip")).show(ctx, |ui| {
            ui.set_max_width(380.);
            ui.heading("Delete this clip?");
            ui.label(path.file_name().unwrap_or_default().to_string_lossy());
            ui.label("This permanently deletes the video from its folder.");
            ui.horizontal(|ui| {
                if ui.button("Cancel").clicked() {
                    self.delete_target = None;
                }
                if ui.button("Delete clip").clicked() {
                    match fs::remove_file(&path) {
                        Ok(()) => self.message("Clip deleted.".into()),
                        Err(e) => self.message(format!("Couldn’t delete the clip · {e}")),
                    }
                    self.delete_target = None;
                    self.scan();
                }
            });
        });
        if modal.should_close() {
            self.delete_target = None;
        }
    }
    fn library(&mut self, ui: &mut Ui) {
        self.heading(
            ui,
            "Clip library",
            "Hover over a clip to preview it. Click to play.",
        );
        let (r, _) = ui.allocate_exact_size(vec2(ui.available_width(), 48.), Sense::hover());
        write(
            ui.painter(),
            r.left_center(),
            Align2::LEFT_CENTER,
            format!("Saved clips  ·  {}", self.library.files.len()),
            display(22.),
            INK,
        );
        let rr = Rect::from_center_size(r.right_center() - vec2(69., 0.), vec2(138., 34.));
        if button(ui, "open folder", rr, "Open folder", "folder", false) {
            match fs::create_dir_all(&self.settings.folder) {
                Ok(()) => {
                    if let Err(e) = desktop::open(&self.settings.folder) {
                        self.message(e);
                    }
                }
                Err(e) => self.message(e.to_string()),
            }
        }
        if self.library.files.is_empty() {
            self.items(ui, 0);
            self.previews = Previews::default();
            return;
        }
        let width = ui.available_width();
        let gap = 14.;
        let columns = (((width + gap) / (200. + gap)).floor() as usize).max(1);
        let side = ((width - gap * (columns - 1) as f32) / columns as f32).min(286.);
        self.previews.begin();
        let mut visible = std::collections::HashSet::new();
        for row in self.library.files.chunks(columns) {
            let (bounds, _) = ui.allocate_exact_size(vec2(width, side), Sense::hover());
            if ui.is_rect_visible(bounds) {
                for (column, item) in row.iter().enumerate() {
                    let rect = Rect::from_min_size(
                        bounds.min + vec2(column as f32 * (side + gap), 0.),
                        Vec2::splat(side),
                    );
                    visible.insert((item.path.clone(), item.modified));
                    let actions = clip_tile(ui, rect, item, &mut self.previews);
                    if actions.0
                        && let Err(error) = desktop::open(&item.path)
                    {
                        self.message(error);
                    }
                    if actions.1 {
                        self.delete_target = Some(item.path.clone());
                    }
                    if actions.2 {
                        *self.editor.borrow_mut() =
                            Some(Editor::open(item.path.clone(), self.settings.audio_quality));
                    }
                }
            }
            ui.add_space(gap - ui.spacing().item_spacing.y);
        }
        self.previews.retain_visible(&visible);
    }
    fn settings(&mut self, ui: &mut Ui, ctx: &Context) {
        self.heading(
            ui,
            "Settings",
            "Choose what the buffer keeps and how you save it.",
        );
        let mut changed = false;
        let mut restart = false;
        let mut rebind = false;
        let old = self.settings.clone();
        Frame::new()
            .fill(PANEL)
            .stroke(Stroke::new(1.0f32, EDGE))
            .corner_radius(8)
            .inner_margin(20)
            .show(ui, |ui| {
                ui.set_width(ui.available_width());
                let width = ui.available_width();
                let row = |ui: &mut Ui, title: &str, desc: &str| {
                    ui.vertical(|ui| {
                        ui.label(RichText::new(title).font(bold(15.)).color(INK));
                        ui.label(RichText::new(desc).size(12.).color(MUTED));
                    });
                };
                ui.horizontal(|ui| {
                    row(
                        ui,
                        "Clip length",
                        "Keep 5 to 600 seconds before each button press.",
                    );
                    ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                        changed |= ui
                            .add(
                                DragValue::new(&mut self.settings.seconds)
                                    .range(5..=600)
                                    .speed(0.2)
                                    .suffix(" s"),
                            )
                            .changed();
                    });
                });
                ui.add_space(8.);
                ui.horizontal_wrapped(|ui| {
                    for n in [5, 10, 15, 30, 60, 120] {
                        if ui
                            .selectable_label(self.settings.seconds == n, format!("{n} s"))
                            .clicked()
                        {
                            self.settings.seconds = n;
                            changed = true;
                        }
                    }
                });
                ui.add_space(10.);
                ui.separator();
                ui.add_space(10.);
                ui.horizontal(|ui| {
                    row(ui, "Clip shortcut", "Works while another app is in focus.");
                    ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                        ComboBox::from_id_salt("hotkey")
                            .selected_text(self.settings.key_name())
                            .width(118.)
                            .show_ui(ui, |ui| {
                                for &(k, name) in KEYS {
                                    rebind |= ui
                                        .selectable_value(&mut self.settings.key, k, name)
                                        .changed();
                                }
                            });
                    });
                });
                ui.add_space(10.);
                ui.separator();
                ui.add_space(10.);
                ui.horizontal(|ui| {
                    row(
                        ui,
                        "Frame rate",
                        "30 FPS reduces capture and encoding work.",
                    );
                    ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                        for n in [60, 30] {
                            restart |= ui
                                .selectable_value(&mut self.settings.fps, n, format!("{n} FPS"))
                                .changed();
                        }
                    });
                });
                ui.add_space(10.);
                ui.separator();
                ui.add_space(10.);
                ui.horizontal(|ui| {
                    row(
                        ui,
                        "Recording resolution",
                        "Changing the size starts a fresh buffer.",
                    );
                    ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                        ComboBox::from_id_salt("resolution")
                            .selected_text(resolution(self.settings.height))
                            .show_ui(ui, |ui| {
                                for &height in HEIGHTS {
                                    restart |= ui
                                        .selectable_value(
                                            &mut self.settings.height,
                                            height,
                                            resolution(height),
                                        )
                                        .changed();
                                }
                            });
                    });
                });
                ui.add_space(10.);
                ui.separator();
                ui.add_space(10.);
                ui.horizontal(|ui| {
                    row(
                        ui,
                        "Video quality",
                        "Higher quality uses more memory and disk space.",
                    );
                    ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                        ComboBox::from_id_salt("video_quality")
                            .selected_text(self.settings.video_quality.label())
                            .show_ui(ui, |ui| {
                                for quality in [
                                    VideoQuality::Compact,
                                    VideoQuality::High,
                                    VideoQuality::Maximum,
                                ] {
                                    restart |= ui
                                        .selectable_value(
                                            &mut self.settings.video_quality,
                                            quality,
                                            quality.label(),
                                        )
                                        .changed();
                                }
                            });
                    });
                });
                ui.add_space(10.);
                ui.separator();
                ui.add_space(10.);
                row(
                    ui,
                    "Clip audio",
                    "24-bit stereo capture. Choose which sources to include.",
                );
                ui.horizontal(|ui| {
                    row(
                        ui,
                        "Audio quality",
                        "Lossless keeps more detail; AAC makes sharing easier.",
                    );
                    ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                        ComboBox::from_id_salt("audio_quality")
                            .selected_text(self.settings.audio_quality.label())
                            .show_ui(ui, |ui| {
                                for quality in [AudioQuality::High, AudioQuality::Lossless] {
                                    changed |= ui
                                        .selectable_value(
                                            &mut self.settings.audio_quality,
                                            quality,
                                            quality.label(),
                                        )
                                        .changed();
                                }
                            });
                    });
                });
                ui.add_space(8.);
                restart |= audio_picker(
                    ui,
                    Source::Playback,
                    &self.playback_devices,
                    &mut self.settings.sound,
                    &mut self.settings.playback_device,
                );
                restart |= audio_picker(
                    ui,
                    Source::Microphone,
                    &self.microphones,
                    &mut self.settings.microphone,
                    &mut self.settings.mic_device,
                );
                ui.add_space(10.);
                ui.separator();
                ui.add_space(10.);
                ui.horizontal(|ui| {
                    row(
                        ui,
                        "Save sound",
                        "Play a soft ping when the clip has been saved.",
                    );
                    ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                        changed |= ui
                            .checkbox(&mut self.settings.save_ping, "Play sound")
                            .changed();
                    });
                });
                ui.add_space(10.);
                ui.separator();
                ui.add_space(10.);
                ui.horizontal(|ui| {
                    row(
                        ui,
                        "Save overlay",
                        "Show a brief popup when the clip has been saved.",
                    );
                    ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                        let toggled = ui
                            .checkbox(&mut self.settings.save_overlay, "Show overlay")
                            .changed();
                        changed |= toggled;
                        if toggled {
                            crate::overlay::set_enabled(self.settings.save_overlay);
                        }
                        if ui
                            .add_enabled(self.settings.save_overlay, Button::new("Preview"))
                            .clicked()
                        {
                            crate::overlay::show();
                        }
                    });
                });
                ui.add_space(10.);
                ui.separator();
                ui.add_space(10.);
                ui.label(RichText::new("Save location").font(bold(15.)).color(INK));
                ui.horizontal_wrapped(|ui| {
                    ui.set_max_width(width);
                    ui.label(
                        RichText::new(self.settings.folder.to_string_lossy())
                            .size(13.)
                            .color(MUTED),
                    );
                    if ui.button("Choose folder…").clicked()
                        && let Some(path) = desktop::choose_folder()
                    {
                        self.settings.folder = path;
                        changed = true;
                        self.scan();
                    }
                });
            });
        if changed || restart || rebind {
            let active = matches!(
                self.engine.lock().unwrap().state,
                State::Live(_) | State::Starting
            );
            if rebind && active {
                self.bind(ctx);
                if self.key_error.is_some() {
                    let error = self.key_error.clone();
                    self.settings.key = old.key;
                    self.bind(ctx);
                    self.key_error = error;
                }
            }
            self.persist();
            if restart && active {
                replay::start(&self.engine);
            }
        }
    }
}
fn clip_tile(ui: &mut Ui, rect: Rect, item: &Item, previews: &mut Previews) -> (bool, bool, bool) {
    let cover = Rect::from_min_max(rect.min + vec2(1., 1.), rect.right_bottom() - vec2(1., 78.));
    let play = interact(
        ui,
        (&item.path, "play"),
        rect.with_max_y(rect.bottom() - 36.),
    );
    let trash = Rect::from_center_size(rect.right_bottom() - vec2(24., 22.), vec2(32., 30.));
    let edit = Rect::from_center_size(trash.center() - vec2(40., 0.), vec2(42., 26.));
    let delete = interact(ui, (&item.path, "delete"), trash).on_hover_text("Delete clip");
    let p = ui.painter();
    box_at(
        p,
        rect,
        4,
        PANEL,
        if play.hovered() || play.has_focus() {
            SLATE
        } else {
            EDGE
        },
    );
    p.rect_filled(cover, 3, NAV);
    let image = previews.frame(ui.ctx(), &item.path, item.modified, play.hovered());
    match image {
        Ok(Some(texture)) => {
            let scale = (cover.width() / 16.).min(cover.height() / 9.);
            let dest = Rect::from_center_size(cover.center(), vec2(16., 9.) * scale);
            p.image(
                texture.id(),
                dest,
                Rect::from_min_max(Pos2::ZERO, pos2(1., 1.)),
                Color32::WHITE,
            );
        }
        result => {
            icon(p, cover.center() - vec2(0., 10.), "film", 26., MUTED);
            write(
                p,
                cover.center() + vec2(0., 18.),
                Align2::CENTER_CENTER,
                if result.is_err() {
                    "Preview unavailable"
                } else {
                    "Loading preview…"
                },
                FontId::proportional(12.),
                MUTED,
            );
        }
    }
    let stem = item.path.file_stem().unwrap_or_default().to_string_lossy();
    let (name, duration) = stem
        .rsplit_once(" · ")
        .filter(|(_, d)| {
            d.strip_suffix('s')
                .is_some_and(|n| n.parse::<u32>().is_ok())
        })
        .map_or((stem.as_ref(), None), |(name, d)| (name, Some(d)));
    if let Some(d) = duration {
        let time = p.layout_no_wrap(d.into(), FontId::monospace(12.), INK);
        let badge = Rect::from_min_size(
            cover.right_bottom() - time.size() - vec2(20., 15.),
            time.size() + vec2(12., 7.),
        );
        p.rect_filled(badge, 3, Color32::from_black_alpha(216));
        p.galley(badge.min + vec2(6., 3.), time, INK);
    }
    let play_center = cover.left_bottom() + vec2(22., -22.);
    p.circle_filled(
        play_center,
        13.,
        if play.hovered() {
            SLATE
        } else {
            Color32::from_black_alpha(190)
        },
    );
    icon(
        p,
        play_center,
        "play",
        16.,
        if play.hovered() { GRAPHITE } else { INK },
    );
    let title = name
        .strip_prefix("Replay ")
        .and_then(|s| chrono::NaiveDateTime::parse_from_str(s, "%Y-%m-%d %H-%M-%S%.3f").ok())
        .map(|t| format!("Replay at {}", t.format("%H:%M:%S")))
        .unwrap_or_else(|| name.to_owned());
    let mut job = text::LayoutJob::simple_singleline(title, bold(16.), INK);
    job.wrap.max_rows = 1;
    job.wrap.max_width = rect.width() - 28.;
    let title = p.layout_job(job);
    p.galley(pos2(rect.left() + 14., cover.bottom() + 10.), title, INK);
    let meta = format!(
        "{}  ·  {}",
        item.date.split("   ").next().unwrap_or(&item.date),
        item.size
    );
    write(
        &p.with_clip_rect(ui.clip_rect().intersect(rect.with_max_x(edit.left() - 2.))),
        rect.left_bottom() + vec2(14., -23.),
        Align2::LEFT_CENTER,
        meta,
        FontId::proportional(12.),
        MUTED,
    );
    if delete.hovered() || delete.has_focus() {
        p.rect_filled(trash, 4, EDGE);
    }
    icon(
        p,
        trash.center(),
        "trash",
        18.,
        if delete.hovered() { INK } else { MUTED },
    );
    let clicked = play.clicked();
    play.on_hover_text(stem.as_ref());
    let edit_clicked = ui
        .push_id((&item.path, "edit"), |ui| ui.put(edit, Button::new("Edit")))
        .inner
        .clicked();
    (clicked, delete.clicked(), edit_clicked)
}

fn audio_picker(
    ui: &mut Ui,
    source: Source,
    devices: &[(String, String)],
    enabled: &mut bool,
    id: &mut Option<String>,
) -> bool {
    let old = (*enabled, id.clone());
    let label = if !*enabled {
        "Off"
    } else if let Some(selected) = id.as_ref() {
        devices
            .iter()
            .find(|(key, _)| key == selected)
            .map_or("Device unavailable", |(_, name)| name.as_str())
    } else {
        "Windows default"
    };
    ui.horizontal(|ui| {
        ui.label(source.label());
        ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
            ComboBox::from_id_salt(source.label())
                .width(224.)
                .truncate()
                .selected_text(label)
                .show_ui(ui, |ui| {
                    if ui.selectable_label(!*enabled, "Off").clicked() {
                        *enabled = false;
                    }
                    if ui
                        .selectable_label(*enabled && id.is_none(), "Windows default")
                        .clicked()
                    {
                        *enabled = true;
                        *id = None;
                    }
                    for (key, name) in devices {
                        if ui
                            .selectable_label(*enabled && id.as_ref() == Some(key), name)
                            .clicked()
                        {
                            *enabled = true;
                            *id = Some(key.clone());
                        }
                    }
                });
        });
    });
    old != (*enabled, id.clone())
}
impl eframe::App for Window {
    fn update(&mut self, ctx: &Context, _: &mut eframe::Frame) {
        self.library.poll(ctx);
        let (state, duration, busy, saves, notice, device_error) = {
            let r = self.engine.lock().unwrap();
            (
                r.state.clone(),
                r.duration(),
                r.busy,
                r.saves,
                r.notice.clone(),
                r.sound_error(),
            )
        };
        if matches!(state, State::Failed(_)) {
            self.shortcut = None;
        }
        if saves != self.last_saves
            || (self.page == Page::Library && self.last_scan.elapsed() > Duration::from_secs(10))
        {
            self.last_saves = saves;
            self.scan();
        }
        self.sidebar(ctx);
        CentralPanel::default()
            .frame(Frame::NONE.fill(BG))
            .show(ctx, |ui| {
                let (r, _) =
                    ui.allocate_exact_size(vec2(ui.available_width(), 55.), Sense::hover());
                let p = ui.painter();
                line(p, r.left_bottom(), r.right_bottom(), EDGE, 1.);
                let name = match self.page {
                    Page::Console => "Replay console",
                    Page::Library => "Clip library",
                    Page::Settings => "Settings",
                };
                write(
                    p,
                    r.left_center() + vec2(27., 0.),
                    Align2::LEFT_CENTER,
                    "Workspace",
                    FontId::proportional(13.),
                    MUTED,
                );
                icon(p, r.left_center() + vec2(103., 0.), "chev", 10., MUTED);
                write(
                    p,
                    r.left_center() + vec2(117., 0.),
                    Align2::LEFT_CENTER,
                    name,
                    FontId::proportional(13.),
                    INK,
                );
                write(
                    p,
                    r.right_center() - vec2(23., 0.),
                    Align2::RIGHT_CENTER,
                    "Local only",
                    FontId::proportional(12.),
                    MUTED,
                );
                p.circle_filled(r.right_center() - vec2(84., 0.), 3., SILVER);
                ScrollArea::vertical()
                    .id_salt(name)
                    .auto_shrink([false, false])
                    .show(ui, |ui| {
                        Frame::NONE
                            .inner_margin(Margin::symmetric(28, 19))
                            .show(ui, |ui| {
                                ui.set_width(ui.available_width());
                                match self.page {
                                    Page::Console => self.console(ui, &state, duration, busy),
                                    Page::Library => self.library(ui),
                                    Page::Settings => self.settings(ui, ctx),
                                }
                                let mut messages = Vec::new();
                                if let State::Failed(ref s) = state {
                                    messages.push(s.clone());
                                }
                                if let Some(ref e) = self.key_error {
                                    messages.push(e.clone());
                                }
                                if !notice.is_empty() {
                                    messages.push(notice);
                                }
                                if let Some(e) = device_error {
                                    messages.push(e);
                                }
                                if !messages.is_empty() {
                                    ui.add_space(8.);
                                    for msg in messages {
                                        ui.label(RichText::new(msg).size(13.).color(SLATE));
                                    }
                                }
                                if let State::Live(ref enc) = state {
                                    ui.add_space(3.);
                                    ui.label(
                                        RichText::new(format!("Primary display   /   {enc}"))
                                            .monospace()
                                            .size(11.)
                                            .color(MUTED),
                                    );
                                }
                            });
                    });
            });
        self.confirm_delete(ctx);
        let outcome = self
            .editor
            .borrow_mut()
            .as_mut()
            .map(|editor| editor.show(ctx));
        match outcome {
            Some(Outcome::Saved(path)) => {
                self.editor.borrow_mut().take();
                self.scan();
                self.message(format!(
                    "Saved {}",
                    path.file_name().unwrap_or_default().to_string_lossy()
                ));
            }
            Some(Outcome::Close) => {
                self.editor.borrow_mut().take();
            }
            _ => {}
        }
        if let Some(path) = &self.shot {
            self.frames += 1;
            if self.frames == 120 {
                ctx.send_viewport_cmd(ViewportCommand::Screenshot(Default::default()));
            }
            let image = ctx.input(|i| {
                i.events.iter().find_map(|e| {
                    if let Event::Screenshot { image, .. } = e {
                        Some(image.clone())
                    } else {
                        None
                    }
                })
            });
            if let Some(img) = image {
                if let Some(parent) = path.parent() {
                    let _ = fs::create_dir_all(parent);
                }
                let bytes: Vec<u8> = img.pixels.iter().flat_map(|c| c.to_array()).collect();
                if let Err(error) = image::save_buffer(
                    path,
                    &bytes,
                    img.width() as u32,
                    img.height() as u32,
                    image::ColorType::Rgba8,
                ) {
                    eprintln!("{error}");
                }
                ctx.send_viewport_cmd(ViewportCommand::Close);
            }
            ctx.request_repaint();
        } else if matches!(state, State::Starting | State::Live(_)) || busy {
            ctx.request_repaint_after(Duration::from_millis(350));
        } else if self.page == Page::Library {
            ctx.request_repaint_after(Duration::from_secs(10));
        }
    }
}
impl Drop for Window {
    fn drop(&mut self) {
        self.shortcut = None;
        replay::shutdown(&self.engine);
    }
}
