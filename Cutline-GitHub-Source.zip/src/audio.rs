use cpal::{
    FromSample, SampleFormat, SizedSample,
    traits::{DeviceTrait, HostTrait, StreamTrait},
};
use std::{
    collections::VecDeque,
    fs::File,
    io::{BufWriter, Seek, SeekFrom, Write},
    path::Path,
    sync::{Arc, Mutex},
    time::{Duration, Instant},
};

#[derive(Clone)]
struct Block {
    end: Instant,
    // Packed 24-bit stereo preserves device precision without a float-sized ring.
    samples: Arc<[u8]>,
}
pub struct AudioRing {
    rate: u32,
    blocks: VecDeque<Block>,
    pub seconds: u32,
    pub failure: Option<String>,
}
pub type Audio = Arc<Mutex<AudioRing>>;
pub fn empty() -> Audio {
    Arc::new(Mutex::new(AudioRing {
        rate: 48000,
        blocks: VecDeque::new(),
        seconds: 30,
        failure: None,
    }))
}

fn block_end(now: Instant, time: cpal::InputStreamTimestamp, duration: Duration) -> Instant {
    // WASAPI timestamps the first frame. Queued packets can arrive in one callback burst.
    if time.capture == cpal::StreamInstant::ZERO {
        return now;
    }
    let age = time.callback.saturating_duration_since(time.capture);
    now.checked_sub(age.saturating_sub(duration)).unwrap_or(now)
}

fn stream<T: SizedSample>(
    device: &cpal::Device,
    config: cpal::StreamConfig,
    ring: Audio,
) -> Result<cpal::Stream, String>
where
    i32: FromSample<T>,
{
    let channels = config.channels as usize;
    let rate = config.sample_rate;
    let errors = ring.clone();
    let result = device
        .build_input_stream(
            config,
            move |input: &[T], info: &_| {
                let now = Instant::now();
                let frames = input.len() / channels;
                let duration = Duration::from_secs_f64(frames as f64 / rate as f64);
                let end = block_end(now, info.timestamp(), duration);
                let mut data = Vec::with_capacity(frames * 6);
                for frame in input.chunks_exact(channels) {
                    for sample in [frame[0], frame[1.min(channels - 1)]] {
                        data.extend_from_slice(&i32::from_sample_(sample).to_le_bytes()[1..]);
                    }
                }
                let block = Block {
                    end,
                    samples: data.into(),
                };
                let mut r = ring.lock().unwrap();
                r.blocks.push_back(block);
                while r.blocks.front().is_some_and(|b| {
                    now.duration_since(b.end) > Duration::from_secs(u64::from(r.seconds) + 2)
                }) {
                    r.blocks.pop_front();
                }
            },
            move |err| {
                errors.lock().unwrap().stream_error(err);
            },
            None,
        )
        .map_err(|e| e.to_string())?;
    result.play().map_err(|e| e.to_string())?;
    Ok(result)
}
#[derive(Clone, Copy, PartialEq)]
pub enum Source {
    Playback,
    Microphone,
}
impl Source {
    pub fn label(self) -> &'static str {
        match self {
            Self::Playback => "Playback",
            Self::Microphone => "Microphone",
        }
    }
    pub fn devices(self) -> Vec<(String, String)> {
        let host = cpal::default_host();
        let describe = |device: cpal::Device| {
            Some((
                device.id().ok()?.to_string(),
                device.description().ok()?.name().to_owned(),
            ))
        };
        match self {
            Self::Playback => host
                .output_devices()
                .into_iter()
                .flatten()
                .filter_map(describe)
                .collect(),
            Self::Microphone => host
                .input_devices()
                .into_iter()
                .flatten()
                .filter_map(describe)
                .collect(),
        }
    }
}
pub fn start(ring: Audio, source: Source, id: Option<&str>) -> Result<cpal::Stream, String> {
    let host = cpal::default_host();
    let device = match id {
        Some(id) => id.parse().ok().and_then(|id| host.device_by_id(&id)),
        None if source == Source::Microphone => host.default_input_device(),
        None => host.default_output_device(),
    }
    .ok_or("Device unavailable")?;
    let config = match source {
        Source::Playback => device.default_output_config(),
        Source::Microphone => device.default_input_config(),
    }
    .map_err(|e| e.to_string())?;
    ring.lock().unwrap().rate = config.sample_rate();
    let format = config.sample_format();
    let default: cpal::StreamConfig = config.into();
    let open = |config| match format {
        SampleFormat::F32 => stream::<f32>(&device, config, ring.clone()),
        SampleFormat::I16 => stream::<i16>(&device, config, ring.clone()),
        SampleFormat::I32 => stream::<i32>(&device, config, ring.clone()),
        _ => Err("Unsupported audio format".into()),
    };
    // Give Windows 100 ms of headroom to retain packets through scheduling delays.
    open(cpal::StreamConfig {
        buffer_size: cpal::BufferSize::Fixed((default.sample_rate / 10).max(1)),
        ..default
    })
    .or_else(|_| open(default))
}
pub struct AudioClip {
    rate: u32,
    blocks: Vec<Block>,
    start: Instant,
    duration: f64,
}
impl AudioRing {
    fn stream_error(&mut self, error: cpal::Error) {
        // A discontinuity flags missing samples. WASAPI continues on the same stream.
        if error.kind() != cpal::ErrorKind::Xrun {
            self.failure = Some(error.to_string());
        }
    }
    #[cfg(test)]
    pub fn test_tone(&mut self, end: Instant) {
        let samples = (0..self.rate * 6)
            .flat_map(|i| {
                let x = ((i as f32 * 440.0 * std::f32::consts::TAU / self.rate as f32).sin()
                    * 9000.0) as i32
                    * 256;
                let bytes = x.to_le_bytes();
                [bytes[0], bytes[1], bytes[2], bytes[0], bytes[1], bytes[2]]
            })
            .collect::<Vec<_>>();
        self.blocks.push_back(Block {
            end,
            samples: samples.into(),
        });
    }
    pub fn snapshot(&self, end: Instant, duration: f64) -> AudioClip {
        let start = end - Duration::from_secs_f64(duration);
        AudioClip {
            rate: self.rate,
            blocks: self
                .blocks
                .iter()
                .filter(|b| b.end > start && b.end < end + Duration::from_secs(1))
                .cloned()
                .collect(),
            start,
            duration,
        }
    }
}
impl AudioClip {
    pub fn write(&self, path: &Path) -> std::io::Result<()> {
        let frames = (self.rate as f64 * self.duration).round() as usize;
        let size = frames
            .checked_mul(6)
            .and_then(|size| u32::try_from(size).ok())
            .filter(|size| *size <= u32::MAX - 36)
            .ok_or_else(|| std::io::Error::other("Audio clip is too large for WAV"))?;
        let file = File::create(path)?;
        // Extending a newly truncated file gives silence in gaps, without allocating a full clip.
        file.set_len(u64::from(size) + 44)?;
        let mut w = BufWriter::with_capacity(64 * 1024, file);
        w.write_all(b"RIFF")?;
        w.write_all(&(size + 36).to_le_bytes())?;
        w.write_all(b"WAVEfmt ")?;
        w.write_all(&16u32.to_le_bytes())?;
        w.write_all(&1u16.to_le_bytes())?;
        w.write_all(&2u16.to_le_bytes())?;
        w.write_all(&self.rate.to_le_bytes())?;
        w.write_all(&(self.rate * 6).to_le_bytes())?;
        w.write_all(&6u16.to_le_bytes())?;
        w.write_all(&24u16.to_le_bytes())?;
        w.write_all(b"data")?;
        w.write_all(&size.to_le_bytes())?;
        let mut position = 0;
        for block in &self.blocks {
            let end = block
                .end
                .saturating_duration_since(self.start)
                .as_secs_f64();
            let first =
                (end * self.rate as f64).round() as isize * 6 - block.samples.len() as isize;
            let dst = first.max(0) as usize;
            let src = (-first).max(0) as usize;
            let count = block
                .samples
                .len()
                .saturating_sub(src)
                .min((size as usize).saturating_sub(dst));
            if count > 0 {
                if dst != position {
                    w.seek(SeekFrom::Start(44 + dst as u64))?;
                }
                w.write_all(&block.samples[src..src + count])?;
                position = dst + count;
            }
        }
        w.flush()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn packed(values: &[i32]) -> Vec<u8> {
        values
            .iter()
            .flat_map(|value| {
                let b = value.to_le_bytes();
                [b[0], b[1], b[2], b[0], b[1], b[2]]
            })
            .collect()
    }

    #[test]
    fn streamed_wav_preserves_24_bit_samples_silence_clipping_and_overlaps() {
        let start = Instant::now();
        let block = |seconds, values: &[i32]| Block {
            end: start + Duration::from_secs_f64(seconds),
            samples: packed(values).into(),
        };
        let clip = AudioClip {
            rate: 10,
            start,
            duration: 1.0,
            blocks: vec![
                block(0.3, &[-8_388_608, 1, 8_388_607, 13, 14]),
                block(0.7, &[20, 21]),
                block(0.6, &[30]),
                block(1.2, &[-8_388_608, 1, 8_388_607, 0]),
            ],
        };
        let file = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("target")
            .join(format!(
                "wav-test-{}-{}.wav",
                std::process::id(),
                chrono::Utc::now().timestamp_micros()
            ));
        std::fs::write(&file, vec![255; 1000]).unwrap();
        clip.write(&file).unwrap();
        let wav = std::fs::read(&file).unwrap();
        assert_eq!(&wav[..4], b"RIFF");
        assert_eq!(&wav[22..24], &2u16.to_le_bytes());
        assert_eq!(&wav[34..36], &24u16.to_le_bytes());
        assert_eq!(&wav[40..44], &60u32.to_le_bytes());
        assert_eq!(
            &wav[44..],
            packed(&[8_388_607, 13, 14, 0, 0, 30, 21, 0, -8_388_608, 1])
        );
        std::fs::remove_file(file).unwrap();
    }

    #[test]
    fn lossless_audio_round_trips_the_low_bits_in_mp4() {
        use crate::{replay::ffmpeg, settings::AudioQuality};
        let folder = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("target")
            .join(format!(
                "alac-test-{}-{}",
                std::process::id(),
                chrono::Utc::now().timestamp_micros()
            ));
        std::fs::create_dir(&folder).unwrap();
        let wav = folder.join("input.wav");
        let mp4 = folder.join("lossless.m4a");
        let samples = packed(
            &(0..4800)
                .map(|i| (i * 104729 % 16_777_216) - 8_388_608)
                .collect::<Vec<_>>(),
        );
        let start = Instant::now();
        AudioClip {
            rate: 48_000,
            start,
            duration: 0.1,
            blocks: vec![Block {
                end: start + Duration::from_millis(100),
                samples: samples.clone().into(),
            }],
        }
        .write(&wav)
        .unwrap();
        let output = ffmpeg()
            .arg("-i")
            .arg(&wav)
            .args(AudioQuality::Lossless.encoder_args())
            .arg(&mp4)
            .output()
            .unwrap();
        assert!(
            output.status.success(),
            "{}",
            String::from_utf8_lossy(&output.stderr)
        );
        let decoded = ffmpeg()
            .arg("-i")
            .arg(&mp4)
            .args(["-f", "s24le", "-c:a", "pcm_s24le", "-"])
            .output()
            .unwrap();
        assert!(decoded.status.success());
        assert_eq!(decoded.stdout, samples);
        std::fs::remove_dir_all(folder).unwrap();
    }

    #[test]
    fn a_capture_gap_keeps_delayed_packets_in_time_and_preserves_device_errors() {
        let ring = empty();
        let mut ring = ring.lock().unwrap();
        ring.stream_error(cpal::ErrorKind::Xrun.into());
        assert!(ring.failure.is_none());

        let now = Instant::now();
        let duration = Duration::from_millis(10);
        let end = |ms: u32| {
            block_end(
                now,
                cpal::InputStreamTimestamp {
                    callback: cpal::StreamInstant::new(1, 80_000_000),
                    capture: cpal::StreamInstant::new(1, ms * 1_000_000),
                },
                duration,
            )
        };
        assert_eq!(now - end(20), Duration::from_millis(50));
        assert_eq!(end(50) - end(20), Duration::from_millis(30));

        ring.stream_error(cpal::ErrorKind::DeviceNotAvailable.into());
        ring.stream_error(cpal::ErrorKind::Xrun.into());
        assert_eq!(
            ring.failure,
            Some(cpal::ErrorKind::DeviceNotAvailable.to_string())
        );
    }
}
