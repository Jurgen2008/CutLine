use eframe::egui::Context;
use std::{
    fs,
    path::{Path, PathBuf},
    sync::mpsc::{self, Receiver, TryRecvError},
    thread,
    time::SystemTime,
};

pub struct Item {
    pub path: PathBuf,
    pub date: String,
    pub size: String,
    pub modified: SystemTime,
}

type ScanResult = Result<Vec<Item>, String>;
struct Pending {
    folder: PathBuf,
    result: Receiver<ScanResult>,
}

#[derive(Default)]
pub struct Library {
    pub files: Vec<Item>,
    pub error: Option<String>,
    folder: PathBuf,
    pending: Option<Pending>,
    rescan: bool,
}

fn scan(folder: &Path) -> ScanResult {
    let dir = match fs::read_dir(folder) {
        Ok(dir) => dir,
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Ok(Vec::new()),
        Err(e) => return Err(format!("Could not read this folder · {e}")),
    };
    let mut files = Vec::new();
    for entry in dir.flatten() {
        let path = entry.path();
        if path
            .extension()
            .is_none_or(|e| !e.eq_ignore_ascii_case("mp4"))
        {
            continue;
        }
        if let Ok(meta) = entry.metadata() {
            if !meta.is_file() {
                continue;
            }
            let modified = meta.modified().unwrap_or(SystemTime::UNIX_EPOCH);
            let date: chrono::DateTime<chrono::Local> = modified.into();
            files.push(Item {
                path,
                modified,
                date: date.format("%b %d, %Y   %H:%M").to_string(),
                size: format!("{:.1} MB", meta.len() as f64 / 1e6),
            });
        }
    }
    files.sort_by_key(|item| std::cmp::Reverse(item.modified));
    Ok(files)
}

impl Library {
    pub fn refresh(&mut self, folder: PathBuf, ctx: &Context) {
        if self.folder != folder {
            self.folder = folder;
            self.files.clear();
            self.error = None;
        }
        if self.pending.is_some() {
            self.rescan = true;
            return;
        }
        self.rescan = false;
        let folder = self.folder.clone();
        let (tx, rx) = mpsc::channel();
        self.pending = Some(Pending {
            folder: folder.clone(),
            result: rx,
        });
        let repaint = ctx.clone();
        thread::spawn(move || {
            let _ = tx.send(scan(&folder));
            repaint.request_repaint();
        });
    }

    pub fn poll(&mut self, ctx: &Context) {
        let Some(pending) = &self.pending else { return };
        let result = match pending.result.try_recv() {
            Ok(result) => result,
            Err(TryRecvError::Empty) => return,
            Err(TryRecvError::Disconnected) => {
                Err("Could not finish reading the clip folder.".into())
            }
        };
        if pending.folder == self.folder {
            match result {
                Ok(files) => {
                    self.files = files;
                    self.error = None;
                }
                Err(error) => self.error = Some(error),
            }
        }
        self.pending = None;
        if self.rescan {
            self.refresh(self.folder.clone(), ctx);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::{Duration, Instant};

    #[test]
    fn stale_scan_cannot_replace_a_new_folder_and_refreshes_are_coalesced() {
        let folder = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("target")
            .join(format!(
                "library-test-{}-{}",
                std::process::id(),
                chrono::Utc::now().timestamp_micros()
            ));
        fs::create_dir_all(&folder).unwrap();
        fs::write(folder.join("clip.MP4"), b"fixture").unwrap();
        fs::write(folder.join("not-video.txt"), b"ignore").unwrap();
        fs::create_dir(folder.join("directory.mp4")).unwrap();
        let ctx = Context::default();
        let (tx, rx) = mpsc::channel();
        let mut library = Library {
            pending: Some(Pending {
                folder: folder.join("old"),
                result: rx,
            }),
            ..Default::default()
        };
        library.refresh(folder.clone(), &ctx);
        library.refresh(folder.clone(), &ctx);
        tx.send(Err("stale error".into())).unwrap();
        library.poll(&ctx);
        assert!(library.error.is_none());
        assert!(library.pending.is_some());
        let start = Instant::now();
        while library.pending.is_some() {
            library.poll(&ctx);
            assert!(start.elapsed() < Duration::from_secs(5));
            thread::sleep(Duration::from_millis(5));
        }
        assert_eq!(library.files.len(), 1);
        assert_eq!(library.files[0].path, folder.join("clip.MP4"));
        fs::remove_dir_all(folder).unwrap();
    }
}
