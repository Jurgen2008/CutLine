#![cfg_attr(target_os = "windows", windows_subsystem = "windows")]
mod audio;
mod design;
mod desktop;
mod editor;
mod library;
mod overlay;
mod preview;
mod replay;
mod settings;
mod tray;
mod window;
use eframe::egui;
fn main() -> eframe::Result {
    let mut args = std::env::args_os().skip(1);
    let mut shot = None;
    let mut from_tray = false;
    while let Some(arg) = args.next() {
        if arg == "--screenshot" {
            shot = args.next().map(std::path::PathBuf::from);
        } else if arg == "--tray" {
            from_tray = true;
        }
    }
    from_tray &= shot.is_none();
    if shot.is_none() && tray::already_in_tray(from_tray) {
        return Ok(());
    }
    let screenshot = shot.is_some();
    let mut app = window::Window::new(shot);
    if from_tray {
        app.start_replay(&egui::Context::default());
        if !tray::wait_for_open() {
            return Ok(());
        }
    } else if !screenshot && let Err(error) = tray::register_startup() {
        app.message(format!(
            "Windows could not enable startup at sign-in · {error}"
        ));
    }
    let icon = image::load_from_memory(include_bytes!("../media/cutline.ico"))
        .expect("embedded Cutline icon")
        .into_rgba8();
    let mut viewport = egui::ViewportBuilder::default()
        .with_icon(egui::IconData {
            width: icon.width(),
            height: icon.height(),
            rgba: icon.into_raw(),
        })
        .with_title("Cutline")
        .with_inner_size([1120., 730.])
        .with_min_inner_size([816., 570.]);
    if screenshot {
        viewport = viewport
            .with_active(false)
            .with_window_level(egui::WindowLevel::AlwaysOnBottom);
    }
    let options = eframe::NativeOptions {
        viewport,
        renderer: eframe::Renderer::Glow,
        vsync: true,
        ..Default::default()
    };
    eframe::run_native(
        "Cutline",
        options,
        Box::new(move |cc| {
            app.open(cc, from_tray);
            Ok(Box::new(app))
        }),
    )
}
