use crate::replay::ffmpeg;
use eframe::egui::{ColorImage, Context, TextureHandle, TextureOptions};
use std::{
    collections::HashMap,
    io::Read,
    path::{Path, PathBuf},
    process::{Command, Stdio},
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
        mpsc::{self, Receiver, TryRecvError},
    },
    thread,
    time::{Duration, Instant, SystemTime},
};

const WIDTH: usize = 288;
const HEIGHT: usize = 162;
const FRAME_BYTES: usize = WIDTH * HEIGHT * 3;
const FRAME_TIME: Duration = Duration::from_millis(250);

#[cfg(test)]
pub(crate) fn decode(path: &Path, animated: bool) -> Vec<ColorImage> {
    decode_with_cancel(path, animated, &AtomicBool::new(false))
}

fn read_output(
    mut command: Command,
    limit: usize,
    cancel: &AtomicBool,
    timeout: Duration,
) -> Vec<u8> {
    if cancel.load(Ordering::Acquire) {
        return Vec::new();
    }
    let Ok(mut child) = command.stdout(Stdio::piped()).stderr(Stdio::null()).spawn() else {
        return Vec::new();
    };
    let output = child.stdout.take().unwrap();
    let reader = thread::spawn(move || {
        let mut bytes = Vec::new();
        output
            .take(limit as u64 + 1)
            .read_to_end(&mut bytes)
            .map(|_| bytes)
    });
    let start = Instant::now();
    let success = loop {
        if cancel.load(Ordering::Acquire) || start.elapsed() >= timeout {
            break false;
        }
        match child.try_wait() {
            Ok(Some(status)) => break status.success(),
            Ok(None) => thread::sleep(Duration::from_millis(25)),
            Err(_) => break false,
        }
    };
    if !success {
        let _ = child.kill();
    }
    let _ = child.wait();
    match reader.join() {
        Ok(Ok(bytes)) if success && bytes.len() <= limit => bytes,
        _ => Vec::new(),
    }
}

fn decode_with_cancel(path: &Path, animated: bool, cancel: &AtomicBool) -> Vec<ColorImage> {
    let mut command = ffmpeg();
    command
        .args(["-threads", "1", "-i"])
        .arg(path)
        .args([
            "-map", "0:v:0", "-an", "-sn", "-dn", "-filter_threads", "1",
            "-vf", "select='isnan(prev_selected_t)+gte(t-prev_selected_t,0.249)',scale=288:162:force_original_aspect_ratio=decrease,pad=288:162:(ow-iw)/2:(oh-ih)/2",
            "-fps_mode", "vfr", "-frames:v", if animated { "8" } else { "1" }, "-threads", "1", "-pix_fmt", "rgb24",
            "-f", "rawvideo", "pipe:1",
        ]);
    read_output(
        command,
        FRAME_BYTES * if animated { 8 } else { 1 },
        cancel,
        Duration::from_secs(8),
    )
    .as_chunks::<FRAME_BYTES>()
    .0
    .iter()
    .map(|rgb| ColorImage::from_rgb([WIDTH, HEIGHT], rgb))
    .collect()
}

type Key = (PathBuf, SystemTime);

#[derive(Default)]
struct Preview {
    frames: Vec<Arc<ColorImage>>,
    texture: Option<TextureHandle>,
    displayed: usize,
    tried_animation: bool,
}

struct Pending {
    key: Key,
    animated: bool,
    result: Receiver<Vec<ColorImage>>,
    cancel: Arc<AtomicBool>,
}
impl Drop for Pending {
    fn drop(&mut self) {
        self.cancel.store(true, Ordering::Release);
    }
}

#[derive(Default)]
pub struct Previews {
    cache: HashMap<Key, Preview>,
    pending: Option<Pending>,
    hovering: Option<(PathBuf, Instant)>,
}

impl Previews {
    pub fn begin(&mut self) {
        if let Some(pending) = &self.pending {
            let frames = match pending.result.try_recv() {
                Ok(frames) => frames,
                Err(TryRecvError::Empty) => return,
                Err(TryRecvError::Disconnected) => Vec::new(),
            };
            let entry = self.cache.entry(pending.key.clone()).or_default();
            entry.tried_animation = pending.animated;
            if !frames.is_empty() {
                entry.frames = frames.into_iter().map(Arc::new).collect();
            }
            self.pending = None;
        }
    }

    pub fn retain_visible(&mut self, visible: &std::collections::HashSet<Key>) {
        if self
            .pending
            .as_ref()
            .is_some_and(|pending| !visible.contains(&pending.key))
        {
            self.pending = None;
        }
        self.cache.retain(|key, _| visible.contains(key));
        if self
            .hovering
            .as_ref()
            .is_some_and(|(path, _)| !visible.iter().any(|(p, _)| p == path))
        {
            self.hovering = None;
        }
    }

    pub fn frame(
        &mut self,
        ctx: &Context,
        path: &Path,
        modified: SystemTime,
        hovered: bool,
    ) -> Result<Option<&TextureHandle>, ()> {
        let key = (path.to_owned(), modified);
        let needs_decode = self
            .cache
            .get(&key)
            .is_none_or(|entry| hovered && !entry.tried_animation && !entry.frames.is_empty());
        if needs_decode && self.pending.is_none() {
            let (tx, rx) = mpsc::channel();
            let file = path.to_owned();
            let repaint = ctx.clone();
            let cancel = Arc::new(AtomicBool::new(false));
            self.pending = Some(Pending {
                key: key.clone(),
                animated: hovered,
                result: rx,
                cancel: cancel.clone(),
            });
            thread::spawn(move || {
                let _ = tx.send(decode_with_cancel(&file, hovered, &cancel));
                repaint.request_repaint();
            });
        }
        let Some(entry) = self.cache.get_mut(&key) else {
            return Ok(None);
        };
        if entry.frames.is_empty() {
            return Err(());
        }
        let index = if hovered && entry.frames.len() > 1 {
            if self.hovering.as_ref().is_none_or(|(file, _)| file != path) {
                self.hovering = Some((path.to_owned(), Instant::now()));
            }
            let elapsed = self.hovering.as_ref().unwrap().1.elapsed();
            ctx.request_repaint_after(FRAME_TIME);
            (elapsed.as_millis() / FRAME_TIME.as_millis()) as usize % entry.frames.len()
        } else {
            if self.hovering.as_ref().is_some_and(|(file, _)| file == path) {
                self.hovering = None;
            }
            0
        };
        let image = &entry.frames[index];
        match &mut entry.texture {
            Some(texture) if index != entry.displayed => {
                texture.set(image.clone(), TextureOptions::LINEAR)
            }
            None => {
                entry.texture =
                    Some(ctx.load_texture("clip preview", image.clone(), TextureOptions::LINEAR))
            }
            _ => {}
        }
        entry.displayed = index;
        Ok(entry.texture.as_ref())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn slow_command() -> Command {
        let mut command = ffmpeg();
        command.args(["-re", "-f", "lavfi", "-i", "anullsrc", "-f", "null", "-"]);
        command
    }

    #[test]
    fn timed_out_and_cancelled_previews_stop_the_decoder() {
        let start = Instant::now();
        assert!(
            read_output(
                slow_command(),
                64,
                &AtomicBool::new(false),
                Duration::from_millis(100)
            )
            .is_empty()
        );
        assert!(start.elapsed() < Duration::from_secs(3));
        let cancel = Arc::new(AtomicBool::new(false));
        let signal = cancel.clone();
        let worker =
            thread::spawn(move || read_output(slow_command(), 64, &signal, Duration::from_secs(8)));
        thread::sleep(Duration::from_millis(100));
        let start = Instant::now();
        cancel.store(true, Ordering::Release);
        assert!(worker.join().unwrap().is_empty());
        assert!(start.elapsed() < Duration::from_secs(3));
    }

    #[test]
    fn leaving_the_page_or_scrolling_past_a_preview_cancels_it() {
        let ctx = Context::default();
        let mut previews = Previews::default();
        let path = Path::new("missing-preview.mp4");
        let _ = previews.frame(&ctx, path, SystemTime::UNIX_EPOCH, false);
        let cancel = previews.pending.as_ref().unwrap().cancel.clone();
        previews.retain_visible(&Default::default());
        assert!(cancel.load(Ordering::Acquire));
        let _ = previews.frame(&ctx, path, SystemTime::UNIX_EPOCH, false);
        let cancel = previews.pending.as_ref().unwrap().cancel.clone();
        drop(previews);
        assert!(cancel.load(Ordering::Acquire));
    }
}
