use serde::{Deserialize, Serialize};
use std::{fs, path::PathBuf};

#[derive(Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct Settings {
    pub seconds: u32,
    pub key: u32,
    pub fps: u32,
    pub height: u32,
    pub video_quality: VideoQuality,
    pub audio_quality: AudioQuality,
    pub sound: bool,
    pub playback_device: Option<String>,
    pub microphone: bool,
    pub mic_device: Option<String>,
    pub save_ping: bool,
    pub save_overlay: bool,
    pub armed: bool,
    pub folder: PathBuf,
}
#[derive(Clone, Copy, Default, PartialEq, Serialize, Deserialize)]
pub enum VideoQuality {
    Compact,
    High,
    #[default]
    Maximum,
}
impl VideoQuality {
    pub fn label(self) -> &'static str {
        match self {
            Self::Compact => "Compact",
            Self::High => "High",
            Self::Maximum => "Maximum",
        }
    }
    pub fn crf(self) -> &'static str {
        match self {
            Self::Compact => "23",
            Self::High => "15",
            Self::Maximum => "12",
        }
    }
}
#[derive(Clone, Copy, Default, PartialEq, Serialize, Deserialize)]
pub enum AudioQuality {
    High,
    #[default]
    Lossless,
}
impl AudioQuality {
    pub fn label(self) -> &'static str {
        match self {
            Self::High => "AAC · 320 kbit/s",
            Self::Lossless => "Lossless · ALAC",
        }
    }
    pub fn encoder_args(self) -> &'static [&'static str] {
        match self {
            Self::High => &["-c:a", "aac", "-ar", "48000", "-ac", "2", "-b:a", "320k"],
            Self::Lossless => &[
                "-c:a",
                "alac",
                "-sample_fmt",
                "s32p",
                "-ar",
                "48000",
                "-ac",
                "2",
            ],
        }
    }
}
pub const HEIGHTS: &[u32] = &[0, 480, 720, 1080, 1440, 2160];
pub fn resolution(height: u32) -> String {
    if height == 0 {
        "Native".into()
    } else {
        format!("{height}p")
    }
}
pub const KEYS: &[(u32, &str)] = &[
    (220, "Backslash"),
    (117, "F6"),
    (118, "F7"),
    (119, "F8"),
    (120, "F9"),
    (121, "F10"),
    (122, "F11"),
];
impl Default for Settings {
    fn default() -> Self {
        let home = std::env::var_os("USERPROFILE")
            .map(PathBuf::from)
            .unwrap_or_default();
        Self {
            seconds: 30,
            key: 220,
            fps: 60,
            height: 0,
            video_quality: VideoQuality::Maximum,
            audio_quality: AudioQuality::Lossless,
            sound: true,
            playback_device: None,
            microphone: false,
            mic_device: None,
            save_ping: true,
            save_overlay: true,
            armed: false,
            folder: home.join("Videos").join("Cutline"),
        }
    }
}

impl Settings {
    fn file() -> PathBuf {
        PathBuf::from(std::env::var_os("LOCALAPPDATA").unwrap_or_default())
            .join("Cutline")
            .join("preferences.json")
    }
    pub fn load() -> Self {
        let mut s: Self = fs::read(Self::file())
            .ok()
            .and_then(|b| serde_json::from_slice(&b).ok())
            .unwrap_or_default();
        s.seconds = s.seconds.clamp(5, 600);
        if !HEIGHTS.contains(&s.height) {
            s.height = 0;
        }
        if ![30, 60].contains(&s.fps) {
            s.fps = 60;
        }
        if !KEYS.iter().any(|k| k.0 == s.key) {
            s.key = 220;
        }
        s
    }
    pub fn save(&self) -> Result<(), String> {
        let p = Self::file();
        fs::create_dir_all(p.parent().unwrap()).map_err(|e| e.to_string())?;
        let tmp = p.with_extension(format!("{}.tmp", std::process::id()));
        fs::write(&tmp, serde_json::to_vec_pretty(self).unwrap())
            .and_then(|_| fs::rename(tmp, p))
            .map_err(|e| e.to_string())
    }
    pub fn key_name(&self) -> &'static str {
        KEYS.iter()
            .find(|e| e.0 == self.key)
            .map_or("Backslash", |k| k.1)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn overlay_preference_survives_round_trip_independently_of_sound() {
        let legacy: Settings = serde_json::from_str(r#"{"save_ping":false}"#).unwrap();
        assert!(legacy.save_overlay);
        assert!(!legacy.save_ping);
        let settings = Settings {
            save_overlay: false,
            save_ping: true,
            ..legacy
        };
        let restored: Settings =
            serde_json::from_str(&serde_json::to_string(&settings).unwrap()).unwrap();
        assert!(!restored.save_overlay);
        assert!(restored.save_ping);
    }
}
