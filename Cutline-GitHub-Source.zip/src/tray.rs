use std::{
    cell::Cell,
    io,
    mem::size_of,
    os::windows::ffi::OsStrExt,
    ptr::{null, null_mut},
    sync::OnceLock,
};
use windows_sys::{
    Win32::{
        Foundation::{HWND, LPARAM, LRESULT, POINT, WPARAM},
        System::{LibraryLoader::GetModuleHandleW, Registry::*},
        UI::{Shell::*, WindowsAndMessaging::*},
    },
    core::w,
};

const CLASS: *const u16 = w!("Cutline.Tray");
const ICON_EVENT: u32 = WM_APP + 1;
const OPEN: u32 = WM_APP + 2;
static TASKBAR_CREATED: OnceLock<u32> = OnceLock::new();

pub fn register_startup() -> io::Result<()> {
    let exe = std::env::current_exe()?;
    let command: Vec<u16> = ['"' as u16]
        .into_iter()
        .chain(exe.as_os_str().encode_wide())
        .chain("\" --tray\0".encode_utf16())
        .collect();
    let status = unsafe {
        RegSetKeyValueW(
            HKEY_CURRENT_USER,
            w!("Software\\Microsoft\\Windows\\CurrentVersion\\Run"),
            w!("Cutline"),
            REG_SZ,
            command.as_ptr().cast(),
            size_of_val(command.as_slice()) as u32,
        )
    };
    if status == 0 {
        Ok(())
    } else {
        Err(io::Error::from_raw_os_error(status as i32))
    }
}

pub fn already_in_tray(quiet: bool) -> bool {
    unsafe {
        let hwnd = FindWindowW(CLASS, null());
        if hwnd.is_null() {
            return false;
        }
        quiet || PostMessageW(hwnd, OPEN, 0, 0) != 0
    }
}

fn notify(hwnd: HWND, action: u32) -> bool {
    unsafe {
        let mut icon = NOTIFYICONDATAW {
            cbSize: size_of::<NOTIFYICONDATAW>() as u32,
            hWnd: hwnd,
            uID: 1,
            uFlags: NIF_MESSAGE | NIF_ICON | NIF_TIP,
            uCallbackMessage: ICON_EVENT,
            // Win32 MAKEINTRESOURCE encodes resource IDs in the pointer's low word.
            hIcon: LoadIconW(
                GetModuleHandleW(null()),
                std::ptr::without_provenance::<u16>(1),
            ),
            ..Default::default()
        };
        for (dest, src) in icon.szTip.iter_mut().zip("Cutline".encode_utf16()) {
            *dest = src;
        }
        Shell_NotifyIconW(action, &icon) != 0
    }
}

fn add_icon(hwnd: HWND) {
    // Explorer may still be starting when Windows runs the sign-in command.
    unsafe {
        if notify(hwnd, NIM_ADD) {
            KillTimer(hwnd, 1);
        } else {
            SetTimer(hwnd, 1, 1500, None);
        }
    }
}

fn menu(hwnd: HWND) -> u32 {
    unsafe {
        let popup = CreatePopupMenu();
        if popup.is_null() {
            return 0;
        }
        AppendMenuW(popup, MF_STRING, 1, w!("Open Cutline"));
        AppendMenuW(popup, MF_STRING, 2, w!("Quit Cutline"));
        let mut pos = POINT::default();
        GetCursorPos(&mut pos);
        SetForegroundWindow(hwnd);
        let item = TrackPopupMenu(
            popup,
            TPM_RETURNCMD | TPM_RIGHTBUTTON,
            pos.x,
            pos.y,
            0,
            hwnd,
            null(),
        );
        DestroyMenu(popup);
        PostMessageW(hwnd, WM_NULL, 0, 0);
        item as u32
    }
}

unsafe extern "system" fn events(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    let action = match msg {
        ICON_EVENT if lp as u32 == WM_LBUTTONUP => 1,
        ICON_EVENT if lp as u32 == WM_RBUTTONUP => menu(hwnd),
        OPEN => 1,
        WM_CLOSE => 2,
        WM_TIMER if wp == 1 => {
            add_icon(hwnd);
            return 0;
        }
        m if m != 0 && TASKBAR_CREATED.get() == Some(&m) => {
            add_icon(hwnd);
            return 0;
        }
        WM_DESTROY => {
            notify(hwnd, NIM_DELETE);
            return 0;
        }
        _ => return unsafe { DefWindowProcW(hwnd, msg, wp, lp) },
    };
    if action == 1 || action == 2 {
        unsafe {
            let main = GetWindow(hwnd, GW_OWNER);
            if main.is_null() {
                PostQuitMessage((action == 1) as i32);
            } else if action == 1 {
                ShowWindow(main, SW_RESTORE);
                SetForegroundWindow(main);
            } else {
                PostMessageW(main, WM_CLOSE, 0, 0);
            }
        }
    }
    0
}

fn create_tray(owner: HWND) -> HWND {
    unsafe {
        TASKBAR_CREATED.get_or_init(|| RegisterWindowMessageW(w!("TaskbarCreated")));
        let instance = GetModuleHandleW(null());
        let class = WNDCLASSW {
            hInstance: instance,
            lpszClassName: CLASS,
            lpfnWndProc: Some(events),
            ..Default::default()
        };
        RegisterClassW(&class);
        let hwnd = CreateWindowExW(
            WS_EX_TOOLWINDOW,
            CLASS,
            w!("Cutline tray"),
            WS_POPUP,
            0,
            0,
            0,
            0,
            owner,
            null_mut(),
            instance,
            null(),
        );
        if !hwnd.is_null() {
            add_icon(hwnd);
        }
        hwnd
    }
}

/// Keep only a hidden Win32 message window until the user opens the interface.
pub fn wait_for_open() -> bool {
    unsafe {
        let hwnd = create_tray(null_mut());
        if hwnd.is_null() {
            return true;
        }
        let mut msg = MSG::default();
        let open = loop {
            match GetMessageW(&mut msg, null_mut(), 0, 0) {
                -1 => break true,
                0 => break msg.wParam == 1,
                _ => {
                    TranslateMessage(&msg);
                    DispatchMessageW(&msg);
                }
            }
        };
        DestroyWindow(hwnd);
        open
    }
}

struct MinimizeHandler {
    tray: Cell<HWND>,
    close_editor: Box<dyn Fn()>,
}

// WM_SIZE arrives even when Windows has suspended painting the minimized window.
unsafe extern "system" fn main_events(
    hwnd: HWND,
    msg: u32,
    wp: WPARAM,
    lp: LPARAM,
    id: usize,
    data: usize,
) -> LRESULT {
    unsafe {
        let handler = &*(data as *const MinimizeHandler);
        if msg == WM_SIZE && wp == SIZE_MINIMIZED as usize {
            (handler.close_editor)();
            if handler.tray.get().is_null() {
                let tray = create_tray(hwnd);
                handler.tray.set(tray);
                if !tray.is_null() {
                    ShowWindow(hwnd, SW_HIDE);
                }
            }
        } else if msg == WM_SIZE || msg == WM_NCDESTROY {
            let tray = handler.tray.replace(null_mut());
            if !tray.is_null() {
                DestroyWindow(tray);
            }
        }
        if msg == WM_NCDESTROY {
            RemoveWindowSubclass(hwnd, Some(main_events), id);
            drop(Box::from_raw(data as *mut MinimizeHandler));
        }
        DefSubclassProc(hwnd, msg, wp, lp)
    }
}

pub fn on_minimize(
    cc: &eframe::CreationContext<'_>,
    close_editor: impl Fn() + 'static,
) -> io::Result<()> {
    use raw_window_handle::{HasWindowHandle, RawWindowHandle};
    let handle = cc.window_handle().map_err(io::Error::other)?;
    let RawWindowHandle::Win32(window) = handle.as_raw() else {
        return Err(io::Error::other("Windows handle unavailable"));
    };
    attach(window.hwnd.get() as HWND, close_editor)
}

fn attach(hwnd: HWND, close_editor: impl Fn() + 'static) -> io::Result<()> {
    let handler = Box::new(MinimizeHandler {
        tray: Cell::new(null_mut()),
        close_editor: Box::new(close_editor),
    });
    let data = Box::into_raw(handler);
    unsafe {
        if SetWindowSubclass(hwnd, Some(main_events), 1, data as usize) == 0 {
            drop(Box::from_raw(data));
            return Err(io::Error::last_os_error());
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::rc::Rc;

    #[test]
    fn minimizing_closes_the_editor_and_tray_click_restores_only_the_window() {
        unsafe {
            let main = CreateWindowExW(
                WS_EX_TOOLWINDOW,
                w!("STATIC"),
                w!("Cutline tray test"),
                WS_OVERLAPPEDWINDOW,
                -20000,
                -20000,
                100,
                100,
                null_mut(),
                null_mut(),
                GetModuleHandleW(null()),
                null(),
            );
            assert!(!main.is_null());
            let closed = Rc::new(Cell::new(0));
            let counter = closed.clone();
            attach(main, move || counter.set(counter.get() + 1)).unwrap();
            ShowWindow(main, SW_SHOWNOACTIVATE);
            assert_eq!(closed.get(), 0);
            for count in 1..=2 {
                ShowWindow(main, SW_MINIMIZE);
                assert_eq!(closed.get(), count);
                assert_eq!(IsWindowVisible(main), 0);
                let mut tray = null_mut();
                loop {
                    tray = FindWindowExW(null_mut(), tray, CLASS, null());
                    assert!(!tray.is_null());
                    if GetWindow(tray, GW_OWNER) == main {
                        break;
                    }
                }
                SendMessageW(tray, ICON_EVENT, 0, WM_LBUTTONUP as isize);
                assert_ne!(IsWindowVisible(main), 0);
                assert_eq!(IsIconic(main), 0);
                assert_eq!(IsWindow(tray), 0);
                assert_eq!(closed.get(), count);
            }
            DestroyWindow(main);
        }
    }
}
