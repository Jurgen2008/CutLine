use eframe::egui::*;
pub const GRAPHITE: Color32 = Color32::from_rgb(0x35, 0x35, 0x35);
pub const SLATE: Color32 = Color32::from_rgb(0xd2, 0xd7, 0xdf);
pub const SILVER: Color32 = Color32::from_rgb(0xbd, 0xbb, 0xb0);
pub const OLIVE: Color32 = Color32::from_rgb(0x8a, 0x89, 0x7c);
pub const BG: Color32 = GRAPHITE;
pub const NAV: Color32 = Color32::from_rgb(43, 43, 42);
pub const PANEL: Color32 = Color32::from_rgb(61, 61, 59);
pub const EDGE: Color32 = Color32::from_rgb(88, 88, 82);
pub const INK: Color32 = SLATE;
pub const MUTED: Color32 = SILVER;
pub fn setup(ctx: &Context) {
    let mut fonts = FontDefinitions::default();
    let fallback = fonts.families[&FontFamily::Proportional].clone();
    for (name, file, family) in [
        ("interface", "bahnschrift.ttf", FontFamily::Proportional),
        (
            "heading",
            "segoeuisb.ttf",
            FontFamily::Name("heading".into()),
        ),
        (
            "display",
            "georgiai.ttf",
            FontFamily::Name("display".into()),
        ),
        ("digits", "CascadiaMono.ttf", FontFamily::Monospace),
    ] {
        let faces = fonts
            .families
            .entry(family)
            .or_insert_with(|| fallback.clone());
        if let Ok(bytes) = std::fs::read(std::path::Path::new("C:/Windows/Fonts").join(file)) {
            fonts
                .font_data
                .insert(name.into(), FontData::from_owned(bytes).into());
            faces.insert(0, name.into());
        }
    }
    ctx.set_fonts(fonts);
    let mut style = (*ctx.style()).clone();
    style.visuals = Visuals::dark();
    style.visuals.panel_fill = BG;
    style.visuals.window_fill = PANEL;
    style.visuals.extreme_bg_color = NAV;
    style.visuals.selection.bg_fill = EDGE;
    style.visuals.selection.stroke = Stroke::new(1.0f32, SLATE);
    style.visuals.hyperlink_color = SLATE;
    let widgets = &mut style.visuals.widgets;
    for (state, fill, stroke) in [
        (&mut widgets.noninteractive, PANEL, SILVER),
        (&mut widgets.inactive, GRAPHITE, SLATE),
        (&mut widgets.hovered, EDGE, SLATE),
        (&mut widgets.active, SLATE, GRAPHITE),
        (&mut widgets.open, EDGE, SLATE),
    ] {
        state.bg_fill = fill;
        state.weak_bg_fill = fill;
        state.fg_stroke.color = stroke;
        state.bg_stroke.color = OLIVE;
    }
    style.text_styles.insert(TextStyle::Heading, display(23.));
    style.spacing.interact_size.y = 32.;
    ctx.set_style(style);
}
pub fn display(size: f32) -> FontId {
    FontId::new(size, FontFamily::Name("display".into()))
}
pub fn bold(size: f32) -> FontId {
    FontId::new(size, FontFamily::Name("heading".into()))
}
pub fn write(
    p: &Painter,
    xy: Pos2,
    align: Align2,
    text: impl ToString,
    font: FontId,
    color: Color32,
) -> Rect {
    p.text(xy, align, text, font, color)
}
pub fn small(p: &Painter, xy: Pos2, text: &str) {
    write(
        p,
        xy,
        Align2::LEFT_CENTER,
        text,
        FontId::monospace(11.),
        MUTED,
    );
}
pub fn box_at(p: &Painter, r: Rect, radius: u8, fill: Color32, border: Color32) {
    p.rect_filled(r, radius, fill);
    p.rect_stroke(r, radius, Stroke::new(1.0f32, border), StrokeKind::Inside);
}
pub fn line(p: &Painter, a: Pos2, b: Pos2, color: Color32, width: f32) {
    p.line_segment([a, b], Stroke::new(width, color));
}
pub fn icon(p: &Painter, center: Pos2, name: &str, size: f32, color: Color32) {
    let point = |x: f32, y: f32| center + vec2((x - 12.) * size / 24., (y - 12.) * size / 24.);
    let seg = |x, y, u, v| line(p, point(x, y), point(u, v), color, 1.5);
    let rect = |x, y, u, v, rad| {
        p.rect_stroke(
            Rect::from_two_pos(point(x, y), point(u, v)),
            rad,
            Stroke::new(1.5f32, color),
            StrokeKind::Inside,
        );
    };
    match name {
        "trash" => {
            seg(4., 6., 20., 6.);
            seg(9., 3., 15., 3.);
            rect(6., 6., 18., 21., 2);
            seg(10., 10., 10., 17.);
            seg(14., 10., 14., 17.);
        }
        "console" => {
            for (x, y) in [(3., 3.), (13., 3.), (3., 13.), (13., 13.)] {
                rect(x, y, x + 8., y + 8., 1);
            }
        }
        "film" => {
            rect(2., 4., 22., 20., 2);
            seg(7., 5., 7., 19.);
            seg(17., 5., 17., 19.);
            for y in [9., 15.] {
                seg(3., y, 7., y);
                seg(17., y, 21., y);
            }
        }
        "settings" => {
            for (y, x) in [(5., 8.), (12., 16.), (19., 10.)] {
                seg(3., y, x - 2., y);
                seg(x + 2., y, 21., y);
                p.circle_stroke(point(x, y), 2.5 * size / 24., Stroke::new(1.5f32, color));
            }
        }
        "folder" => {
            let pts = [
                (2., 6.),
                (9., 6.),
                (11., 9.),
                (21., 9.),
                (21., 19.),
                (2., 19.),
                (2., 6.),
            ];
            for ab in pts.windows(2) {
                seg(ab[0].0, ab[0].1, ab[1].0, ab[1].1);
            }
        }
        "keyboard" => {
            rect(1., 5., 23., 19., 2);
            for x in [5., 9., 13., 17.] {
                seg(x, 9., x + 1., 9.);
                seg(x, 12., x + 1., 12.);
            }
            seg(7., 15.5, 17., 15.5);
        }
        "display" => {
            rect(2., 3., 22., 17., 2);
            seg(12., 17., 12., 21.);
            seg(7., 21., 17., 21.);
        }
        "audio" => {
            for (x, h) in [(3., 3.), (7., 7.), (12., 10.), (17., 5.), (21., 2.)] {
                seg(x, 12. - h, x, 12. + h);
            }
        }
        "arrow" => {
            seg(5., 12., 19., 12.);
            seg(13., 6., 19., 12.);
            seg(13., 18., 19., 12.);
        }
        "chev" => {
            seg(9., 6., 15., 12.);
            seg(15., 12., 9., 18.);
        }
        "power" => {
            seg(12., 2., 12., 12.);
            let pts: Vec<_> = (0..=32)
                .map(|i| {
                    let a = (-50. + 280. * i as f32 / 32.).to_radians();
                    point(12. + 8. * a.cos(), 12. + 8. * a.sin())
                })
                .collect();
            p.add(Shape::line(pts, Stroke::new(1.6f32, color)));
        }
        "pause" => {
            seg(8., 5., 8., 19.);
            seg(16., 5., 16., 19.);
        }
        "save" => {
            rect(3., 4., 21., 20., 2);
            seg(8., 4., 8., 10.);
            seg(8., 10., 16., 10.);
            seg(16., 10., 16., 4.);
            rect(7., 14., 17., 20., 0);
        }
        "play" => {
            p.add(Shape::convex_polygon(
                vec![point(7., 4.), point(20., 12.), point(7., 20.)],
                color,
                Stroke::NONE,
            ));
        }
        "storage" => {
            rect(2., 5., 22., 19., 3);
            seg(5., 15., 7., 15.);
            seg(10., 15., 12., 15.);
        }
        _ => {}
    }
}
pub fn interact(ui: &mut Ui, id: impl std::hash::Hash, rect: Rect) -> Response {
    ui.interact(rect, ui.id().with(id), Sense::click())
        .on_hover_cursor(CursorIcon::PointingHand)
}
pub fn button(ui: &mut Ui, id: &str, r: Rect, label: &str, symbol: &str, primary: bool) -> bool {
    let response = interact(ui, id, r);
    let bg = if primary {
        if response.hovered() { SILVER } else { SLATE }
    } else if response.hovered() {
        EDGE
    } else {
        PANEL
    };
    box_at(ui.painter(), r, 6, bg, if primary { bg } else { EDGE });
    let color = if primary { GRAPHITE } else { INK };
    let centered = r.center();
    let font = bold(14.);
    let gal = ui
        .painter()
        .layout_no_wrap(label.into(), font.clone(), color);
    let shift = if symbol.is_empty() { 0. } else { 12. };
    let x = centered.x - gal.size().x / 2. + shift;
    if !symbol.is_empty() {
        icon(ui.painter(), pos2(x - 16., centered.y), symbol, 17., color);
    }
    write(
        ui.painter(),
        pos2(x, centered.y - 1.),
        Align2::LEFT_CENTER,
        label,
        font,
        color,
    );
    response.clicked()
}
pub fn mark(p: &Painter, r: Rect) {
    p.rect_filled(r, 7, SLATE);
    for (offset, wide) in [(0.15, 0.19), (0.40, 0.12), (0.58, 0.10)] {
        let pt = |x, y| r.min + vec2(r.width() * x, r.height() * y);
        p.add(Shape::convex_polygon(
            vec![
                pt(offset, 0.73),
                pt(offset + 0.19, 0.27),
                pt(offset + 0.19 + wide, 0.27),
                pt(offset + wide, 0.73),
            ],
            GRAPHITE,
            Stroke::NONE,
        ));
    }
}
// A stack of film frames gives the buffer a recognizable silhouette at any window width.
pub fn film_stack(p: &Painter, r: Rect) {
    let p = p.with_clip_rect(r);
    let w = r.width();
    let h = r.height();
    let at = |x: f32, y: f32| pos2(r.min.x + x * w, r.min.y + y * h);
    for i in 0..=(w / 14.) as i32 {
        for j in 0..=(h / 14.) as i32 {
            p.circle_filled(r.min + vec2(i as f32 * 14., j as f32 * 14.), 0.8, OLIVE);
        }
    }
    for i in (0..12).rev() {
        let t = i as f32 / 11.;
        let x = 0.12 + t * 0.27;
        let y = 0.34 - t * 0.18;
        let q = |u: f32, v: f32| at(x + u * 0.47 + v * 0.145, y - u * 0.14 + v * 0.61);
        let color = GRAPHITE;
        let fill = if i == 0 {
            SLATE
        } else if i % 3 == 0 {
            SILVER
        } else {
            OLIVE
        };
        p.add(Shape::convex_polygon(
            vec![q(0., 0.), q(1., 0.), q(1., 1.), q(0., 1.)],
            fill,
            Stroke::new(1.2f32, color),
        ));
        if i == 0 {
            p.add(Shape::convex_polygon(
                vec![q(0.06, 0.18), q(0.94, 0.18), q(0.94, 0.82), q(0.06, 0.82)],
                GRAPHITE,
                Stroke::NONE,
            ));
            for j in 0..9 {
                let x = 0.055 + j as f32 * 0.106;
                for y in [0.055, 0.88] {
                    p.add(Shape::convex_polygon(
                        vec![
                            q(x, y),
                            q(x + 0.052, y),
                            q(x + 0.052, y + 0.065),
                            q(x, y + 0.065),
                        ],
                        color,
                        Stroke::NONE,
                    ));
                }
            }
            p.add(Shape::convex_polygon(
                vec![q(0.44, 0.32), q(0.44, 0.68), q(0.64, 0.50)],
                SLATE,
                Stroke::NONE,
            ));
        }
    }
}
