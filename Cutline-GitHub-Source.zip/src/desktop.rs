use crate::replay::{self, Engine};
use std::{
    ffi::OsStr,
    os::windows::ffi::OsStrExt,
    path::{Path, PathBuf},
    ptr::{null, null_mut},
    sync::mpsc,
    thread,
};
use windows_sys::Win32::{
    System::{Com::*, Threading::GetCurrentThreadId},
    UI::{Input::KeyboardAndMouse::*, Shell::*, WindowsAndMessaging::*},
};

pub struct Shortcut {
    thread_id: u32,
    worker: Option<thread::JoinHandle<()>>,
}
pub fn save_ping() {
    use windows_sys::Win32::Media::Audio::{PlaySoundA, SND_ASYNC, SND_MEMORY, SND_NODEFAULT};
    // Asynchronous playback needs the wave bytes to outlive this call.
    let wave = include_bytes!("../media/clip-saved.wav");
    unsafe {
        PlaySoundA(
            wave.as_ptr(),
            null_mut(),
            SND_MEMORY | SND_ASYNC | SND_NODEFAULT,
        );
    }
}
impl Shortcut {
    #[cfg(test)]
    pub fn dispatch_test_message(&self) -> bool {
        unsafe { PostThreadMessageW(self.thread_id, WM_HOTKEY, 1, 0) != 0 }
    }
    pub fn bind(key: u32, engine: Engine, ctx: eframe::egui::Context) -> Result<Self, String> {
        let (tx, rx) = mpsc::sync_channel::<Result<u32, String>>(1);
        let worker = thread::spawn(move || unsafe {
            let mut message = MSG::default();
            PeekMessageW(&mut message, null_mut(), 0, 0, PM_NOREMOVE);
            if RegisterHotKey(null_mut(), 1, MOD_NOREPEAT, key) == 0 {
                let _ = tx.send(Err(
                    "Shortcut unavailable. Choose another key in Settings.".into()
                ));
                return;
            }
            let _ = tx.send(Ok(GetCurrentThreadId()));
            while GetMessageW(&mut message, null_mut(), 0, 0) > 0 {
                if message.message == WM_HOTKEY {
                    replay::save(&engine);
                    ctx.request_repaint();
                }
            }
            UnregisterHotKey(null_mut(), 1);
        });
        let thread_id = rx
            .recv()
            .map_err(|_| "Could not start the shortcut listener")??;
        Ok(Self {
            thread_id,
            worker: Some(worker),
        })
    }
}
impl Drop for Shortcut {
    fn drop(&mut self) {
        unsafe {
            PostThreadMessageW(self.thread_id, WM_QUIT, 0, 0);
        };
        if let Some(w) = self.worker.take() {
            let _ = w.join();
        }
    }
}
fn wide(p: &OsStr) -> Vec<u16> {
    p.encode_wide().chain(Some(0)).collect()
}
pub fn open(path: &Path) -> Result<(), String> {
    let file = wide(path.as_os_str());
    let n = unsafe {
        ShellExecuteW(
            null_mut(),
            null(),
            file.as_ptr(),
            null(),
            null(),
            SW_SHOWNORMAL,
        )
    } as isize;
    if n <= 32 {
        Err(format!("Windows could not open this item (error {n})."))
    } else {
        Ok(())
    }
}
pub fn choose_folder() -> Option<PathBuf> {
    // The Windows shell folder picker requires a single-threaded COM apartment.
    thread::spawn(|| unsafe {
        if CoInitializeEx(null(), COINIT_APARTMENTTHREADED as u32) < 0 {
            return None;
        }
        let title = wide(OsStr::new("Choose where to save your clips"));
        let info = BROWSEINFOW {
            lpszTitle: title.as_ptr(),
            ulFlags: BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE,
            ..Default::default()
        };
        let id = SHBrowseForFolderW(&info);
        let mut buf = [0u16; 260];
        let path = if !id.is_null() && SHGetPathFromIDListW(id, buf.as_mut_ptr()) != 0 {
            Some(PathBuf::from(String::from_utf16_lossy(
                &buf[..buf.iter().position(|&c| c == 0).unwrap_or(buf.len())],
            )))
        } else {
            None
        };
        CoTaskMemFree(id.cast());
        CoUninitialize();
        path
    })
    .join()
    .ok()
    .flatten()
}
