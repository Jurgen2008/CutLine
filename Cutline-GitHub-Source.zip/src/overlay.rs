use std::{
    mem::size_of,
    ptr::{null, null_mut},
    sync::{
        OnceLock,
        atomic::{AtomicBool, Ordering},
        mpsc,
    },
    thread,
};
use windows_sys::{
    Win32::{
        Foundation::{HWND, LPARAM, LRESULT, RECT, WPARAM},
        Graphics::Gdi::*,
        System::LibraryLoader::GetModuleHandleW,
        UI::{HiDpi::GetDpiForWindow, WindowsAndMessaging::*},
    },
    core::w,
};

const SHOW: u32 = WM_APP + 20;
const HIDE: u32 = WM_APP + 21;
const TIMER: usize = 1;
const DURATION_MS: u32 = 2500;
// HWND is thread-affine; callers only post messages using its numeric value.
static WINDOW: OnceLock<usize> = OnceLock::new();
static ENABLED: AtomicBool = AtomicBool::new(true);

pub fn set_enabled(enabled: bool) {
    ENABLED.store(enabled, Ordering::Release);
    if !enabled {
        hide();
    }
}

pub fn show() {
    if !ENABLED.load(Ordering::Acquire) {
        return;
    }
    let hwnd = *WINDOW.get_or_init(|| {
        let (tx, rx) = mpsc::sync_channel(1);
        thread::spawn(move || {
            let hwnd = create_window();
            let _ = tx.send(hwnd as usize);
            if hwnd.is_null() {
                return;
            }
            // SAFETY: this worker owns the window and dispatches its message queue.
            unsafe {
                let mut message = MSG::default();
                while GetMessageW(&mut message, null_mut(), 0, 0) > 0 {
                    TranslateMessage(&message);
                    DispatchMessageW(&message);
                }
                DestroyWindow(hwnd);
            }
        });
        rx.recv().unwrap_or(0)
    });
    if hwnd != 0 {
        // SAFETY: PostMessage marshals the request to the window's owning thread.
        unsafe {
            PostMessageW(hwnd as HWND, SHOW, 0, 0);
        }
    }
}

pub fn hide() {
    if let Some(&hwnd) = WINDOW.get().filter(|&&hwnd| hwnd != 0) {
        // SAFETY: the overlay window lives until process exit; no GDI work occurs here.
        unsafe {
            PostMessageW(hwnd as HWND, HIDE, 0, 0);
        }
    }
}

fn create_window() -> HWND {
    // SAFETY: class strings are static and the callback remains valid for the process lifetime.
    unsafe {
        let instance = GetModuleHandleW(null());
        let class = WNDCLASSW {
            hInstance: instance,
            lpszClassName: w!("Cutline.SaveOverlay"),
            lpfnWndProc: Some(events),
            ..Default::default()
        };
        if RegisterClassW(&class) == 0 {
            return null_mut();
        }
        let hwnd = CreateWindowExW(
            WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE | WS_EX_TRANSPARENT | WS_EX_LAYERED,
            class.lpszClassName,
            w!("Cutline · Clip saved"),
            WS_POPUP,
            0,
            0,
            336,
            88,
            null_mut(),
            null_mut(),
            instance,
            null(),
        );
        if !hwnd.is_null() {
            SetLayeredWindowAttributes(hwnd, 0, 248, LWA_ALPHA);
            // Windows can omit the notification from desktop-capture recordings.
            SetWindowDisplayAffinity(hwnd, WDA_EXCLUDEFROMCAPTURE);
        }
        hwnd
    }
}

unsafe extern "system" fn events(hwnd: HWND, message: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    // SAFETY: Win32 calls this on the window's owning thread with a live HWND.
    unsafe {
        match message {
            SHOW => {
                if !ENABLED.load(Ordering::Acquire) {
                    return 0;
                }
                let foreground = GetForegroundWindow();
                let monitor = MonitorFromWindow(foreground, MONITOR_DEFAULTTOPRIMARY);
                let mut info = MONITORINFO {
                    cbSize: size_of::<MONITORINFO>() as u32,
                    ..Default::default()
                };
                if GetMonitorInfoW(monitor, &mut info) == 0 {
                    return 0;
                }
                let dpi = GetDpiForWindow(foreground).max(96) as i32;
                let width = 336 * dpi / 96;
                let height = 88 * dpi / 96;
                let margin = 24 * dpi / 96;
                SetWindowPos(
                    hwnd,
                    HWND_TOPMOST,
                    info.rcWork.right - width - margin,
                    info.rcWork.top + margin,
                    width,
                    height,
                    SWP_NOACTIVATE | SWP_SHOWWINDOW,
                );
                InvalidateRect(hwnd, null(), 0);
                // A second clip reuses the window and restarts the same timer.
                if SetTimer(hwnd, TIMER, DURATION_MS, None) == 0 {
                    ShowWindow(hwnd, SW_HIDE);
                }
                0
            }
            HIDE | WM_TIMER => {
                KillTimer(hwnd, TIMER);
                ShowWindow(hwnd, SW_HIDE);
                0
            }
            WM_PAINT => {
                paint(hwnd);
                0
            }
            WM_ERASEBKGND => 1,
            WM_MOUSEACTIVATE => MA_NOACTIVATE as isize,
            WM_NCHITTEST => HTTRANSPARENT as isize,
            _ => DefWindowProcW(hwnd, message, wp, lp),
        }
    }
}

fn paint(hwnd: HWND) {
    // SAFETY: paint resources are used only in this callback and released before EndPaint.
    unsafe {
        let mut paint = PAINTSTRUCT::default();
        let dc = BeginPaint(hwnd, &mut paint);
        let mut rect = RECT::default();
        GetClientRect(hwnd, &mut rect);
        let scale = (rect.right - rect.left) as f32 / 336.0;
        let px = |n: i32| (n as f32 * scale).round() as i32;
        let background = CreateSolidBrush(0x002b2b2b);
        FillRect(dc, &rect, background);
        DeleteObject(background);
        let accent = CreateSolidBrush(0x00dad6d3);
        let stripe = RECT {
            left: 0,
            top: 0,
            right: px(5),
            bottom: rect.bottom,
        };
        FillRect(dc, &stripe, accent);
        DeleteObject(accent);
        SetBkMode(dc, TRANSPARENT as i32);
        text(
            dc,
            w!("✓"),
            RECT {
                left: px(19),
                top: px(21),
                right: px(55),
                bottom: px(65),
            },
            px(27),
            600,
            0x00dad6d3,
        );
        text(
            dc,
            w!("Clip saved"),
            RECT {
                left: px(65),
                top: px(16),
                right: rect.right - px(16),
                bottom: px(46),
            },
            px(20),
            600,
            0x00dad6d3,
        );
        text(
            dc,
            w!("Ready in your clip library"),
            RECT {
                left: px(65),
                top: px(47),
                right: rect.right - px(16),
                bottom: px(72),
            },
            px(13),
            400,
            0x00b1b1aa,
        );
        EndPaint(hwnd, &paint);
    }
}

unsafe fn text(dc: HDC, value: *const u16, mut rect: RECT, size: i32, weight: i32, color: u32) {
    // SAFETY: value is a static nul-terminated string and dc/rect belong to the active paint.
    unsafe {
        let font = CreateFontW(
            -size,
            0,
            0,
            0,
            weight,
            0,
            0,
            0,
            DEFAULT_CHARSET as u32,
            OUT_DEFAULT_PRECIS as u32,
            CLIP_DEFAULT_PRECIS as u32,
            CLEARTYPE_QUALITY as u32,
            DEFAULT_PITCH as u32,
            w!("Segoe UI"),
        );
        let previous = SelectObject(dc, font);
        SetTextColor(dc, color);
        DrawTextW(
            dc,
            value,
            -1,
            &mut rect,
            DT_LEFT | DT_SINGLELINE | DT_VCENTER | DT_NOPREFIX,
        );
        SelectObject(dc, previous);
        DeleteObject(font);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::{Duration, Instant};

    #[test]
    fn overlay_does_not_take_focus_and_hides_on_request_and_timeout() {
        let wait_visible = |hwnd, visible| {
            let start = Instant::now();
            // Posted UI work is asynchronous; SendMessage can overtake a posted SHOW.
            while (unsafe { IsWindowVisible(hwnd) } != 0) != visible {
                assert!(
                    start.elapsed() < Duration::from_secs(5),
                    "Unexpected overlay visibility"
                );
                thread::sleep(Duration::from_millis(20));
            }
        };
        // SAFETY: only window queries/messages cross threads; GDI remains on its owner.
        unsafe {
            let foreground = GetForegroundWindow();
            show();
            let hwnd = *WINDOW.get().unwrap() as HWND;
            assert!(!hwnd.is_null());
            wait_visible(hwnd, true);
            assert_eq!(GetForegroundWindow(), foreground);
            let styles = GetWindowLongPtrW(hwnd, GWL_EXSTYLE) as u32;
            assert_eq!(
                styles & (WS_EX_NOACTIVATE | WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW),
                WS_EX_NOACTIVATE | WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW
            );
            hide();
            wait_visible(hwnd, false);
            set_enabled(false);
            show();
            SendMessageW(hwnd, WM_NULL, 0, 0);
            assert_eq!(IsWindowVisible(hwnd), 0);
            set_enabled(true);
            show();
            wait_visible(hwnd, true);
            let start = Instant::now();
            while IsWindowVisible(hwnd) != 0 {
                assert!(
                    start.elapsed() < Duration::from_secs(5),
                    "Overlay did not time out"
                );
                thread::sleep(Duration::from_millis(20));
            }
        }
    }
}
