use crate::{design, replay::ffmpeg, settings::AudioQuality};
use eframe::egui::*;
use std::{
    fs,
    io::{self, Read},
    path::{Path, PathBuf},
    process::{Child, Command, Stdio},
    thread::{self, JoinHandle},
    time::Duration,
};

// Keep the process handle in the editor so closing it also stops in-flight work.
struct Job {
    child: Child,
    stdout: JoinHandle<io::Result<Vec<u8>>>,
    stderr: JoinHandle<io::Result<Vec<u8>>>,
}

fn drain(mut pipe: impl Read + Send + 'static) -> JoinHandle<io::Result<Vec<u8>>> {
    thread::spawn(move || {
        let mut bytes = Vec::new();
        pipe.read_to_end(&mut bytes)?;
        Ok(bytes)
    })
}

impl Job {
    fn start(mut command: Command) -> Result<Self, String> {
        let mut child = command
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .spawn()
            .map_err(|e| format!("Could not start the video tool · {e}"))?;
        let stdout = drain(child.stdout.take().unwrap());
        let stderr = drain(child.stderr.take().unwrap());
        Ok(Self {
            child,
            stdout,
            stderr,
        })
    }

    fn finish(self) -> Result<(Vec<u8>, String), String> {
        let output = self
            .stdout
            .join()
            .map_err(|_| "Preview reader stopped")?
            .map_err(|e| e.to_string())?;
        let log = self
            .stderr
            .join()
            .map_err(|_| "Video reader stopped")?
            .map_err(|e| e.to_string())?;
        let log = String::from_utf8_lossy(&log).into_owned();
        let mut child = self.child;
        if child.wait().map_err(|e| e.to_string())?.success() {
            Ok((output, log))
        } else {
            Err(format!(
                "Could not process this clip · {}",
                log.lines().last().unwrap_or("Video tool failed")
            ))
        }
    }

    fn stop(&mut self) {
        let _ = self.child.kill();
        let _ = self.child.wait();
    }
}

type Range = (u64, u64); // Milliseconds on the original clip.

fn kept_ranges(duration: u64, cuts: &[Range]) -> Vec<Range> {
    let mut cuts = cuts.to_vec();
    cuts.sort_unstable();
    let mut keep = Vec::new();
    let mut cursor = 0;
    for (start, end) in cuts {
        if cursor < start {
            keep.push((cursor, start));
        }
        cursor = cursor.max(end);
    }
    if cursor < duration {
        keep.push((cursor, duration));
    }
    keep
}

fn stamp(ms: u64) -> String {
    format!("{}:{:02}.{:03}", ms / 60000, ms / 1000 % 60, ms % 1000)
}

fn metadata(log: &str) -> Result<(u64, bool), String> {
    let input = log.split("Output #").next().unwrap_or(log);
    let duration = input
        .lines()
        .find_map(|line| {
            let value = line.trim().strip_prefix("Duration: ")?.split(',').next()?;
            let mut fields = value.split(':');
            let hours: u64 = fields.next()?.parse().ok()?;
            let minutes: u64 = fields.next()?.parse().ok()?;
            let seconds: f64 = fields.next()?.parse().ok()?;
            Some((hours * 3600 + minutes * 60) * 1000 + (seconds * 1000.).round() as u64)
        })
        .filter(|ms| *ms > 0)
        .ok_or("Could not read the length of this clip.")?;
    let audio = input
        .lines()
        .any(|l| l.trim_start().starts_with("Stream #") && l.contains("Audio:"));
    Ok((duration, audio))
}

fn export_command(
    source: &Path,
    output: &Path,
    keep: &[Range],
    audio: bool,
    quality: AudioQuality,
) -> Command {
    let mut filters = Vec::new();
    let mut inputs = String::new();
    for (i, &(start, end)) in keep.iter().enumerate() {
        let limits = format!(
            "start={:.3}:end={:.3}",
            start as f64 / 1000.,
            end as f64 / 1000.
        );
        filters.push(format!("[0:v:0]trim={limits},setpts=PTS-STARTPTS[v{i}]"));
        inputs.push_str(&format!("[v{i}]"));
        if audio {
            filters.push(format!("[0:a:0]atrim={limits},asetpts=PTS-STARTPTS[a{i}]"));
            inputs.push_str(&format!("[a{i}]"));
        }
    }
    filters.push(format!(
        "{inputs}concat=n={}:v=1:a={}[video]{}",
        keep.len(),
        u8::from(audio),
        if audio { "[audio]" } else { "" }
    ));
    let mut cmd = ffmpeg();
    cmd.arg("-i")
        .arg(source)
        .arg("-filter_complex")
        .arg(filters.join(";"))
        .args(["-map", "[video]"]);
    if audio {
        cmd.args(["-map", "[audio]"]).args(quality.encoder_args());
    }
    cmd.args([
        "-c:v",
        "libx264",
        "-preset",
        "veryfast",
        "-crf",
        "12",
        "-threads",
        "4",
        "-pix_fmt",
        "yuv420p",
        "-movflags",
        "+faststart",
        "-f",
        "mp4",
        "-y",
    ])
    .arg(output);
    cmd
}

struct PartialFile(PathBuf);

impl PartialFile {
    fn new(source: &Path) -> io::Result<Self> {
        let path = source.with_file_name(format!(
            ".cutline-edit-{}-{}.part",
            std::process::id(),
            chrono::Utc::now().timestamp_micros()
        ));
        fs::File::create_new(&path)?;
        Ok(Self(path))
    }
    fn publish(&self, source: &Path) -> io::Result<PathBuf> {
        let name = source.file_stem().unwrap_or_default().to_string_lossy();
        for i in 1.. {
            let suffix = if i == 1 {
                String::new()
            } else {
                format!(" ({i})")
            };
            let path = source.with_file_name(format!("{name} - edited{suffix}.mp4"));
            match fs::File::create_new(&path) {
                Ok(file) => drop(file),
                Err(e) if e.kind() == io::ErrorKind::AlreadyExists => continue,
                Err(e) => return Err(e),
            }
            if let Err(e) = fs::rename(&self.0, &path) {
                let _ = fs::remove_file(&path);
                return Err(e);
            }
            return Ok(path);
        }
        unreachable!()
    }
}
impl Drop for PartialFile {
    fn drop(&mut self) {
        let _ = fs::remove_file(&self.0);
    }
}

enum Task {
    Inspect,
    Frame(u64),
    Export(PartialFile),
}

pub struct Editor {
    source: PathBuf,
    duration: u64,
    audio: bool,
    audio_quality: AudioQuality,
    cursor: u64,
    selection: Range,
    cuts: Vec<Range>,
    frame: Option<TextureHandle>,
    requested: Option<u64>,
    active: Option<(Job, Task)>,
    error: String,
}

pub enum Outcome {
    Open,
    Close,
    Saved(PathBuf),
}

impl Editor {
    pub fn open(source: PathBuf, audio_quality: AudioQuality) -> Self {
        let mut editor = Self {
            source,
            duration: 0,
            audio: false,
            audio_quality,
            cursor: 0,
            selection: (0, 0),
            cuts: vec![],
            frame: None,
            requested: None,
            active: None,
            error: String::new(),
        };
        let mut cmd = ffmpeg();
        cmd.args(["-loglevel", "info", "-i"])
            .arg(&editor.source)
            .args(["-map", "0:v:0", "-c", "copy", "-t", "0", "-f", "null", "-"]);
        editor.start(cmd, Task::Inspect);
        editor
    }

    fn start(&mut self, cmd: Command, task: Task) {
        self.stop();
        match Job::start(cmd) {
            Ok(job) => self.active = Some((job, task)),
            Err(e) => self.error = e,
        }
    }
    fn stop(&mut self) {
        if let Some((mut job, _task)) = self.active.take() {
            job.stop();
        }
    }
    fn poll(&mut self, ctx: &Context) -> Result<Option<PathBuf>, String> {
        if let Some((job, _)) = &mut self.active {
            if job.child.try_wait().map_err(|e| e.to_string())?.is_none() {
                ctx.request_repaint_after(Duration::from_millis(40));
                return Ok(None);
            }
            let (job, task) = self.active.take().unwrap();
            let (bytes, log) = job.finish()?;
            match task {
                Task::Inspect => {
                    (self.duration, self.audio) = metadata(&log)?;
                    self.selection.1 = self.duration;
                }
                Task::Frame(time) => {
                    if bytes.len() == 512 * 288 * 3 {
                        self.frame = Some(ctx.load_texture(
                            "edit frame",
                            ColorImage::from_rgb([512, 288], &bytes),
                            TextureOptions::LINEAR,
                        ));
                    } else if time == 0 || self.frame.is_none() {
                        return Err("Frame preview unavailable.".into());
                    }
                }
                Task::Export(file) => {
                    return file
                        .publish(&self.source)
                        .map(Some)
                        .map_err(|e| format!("Could not save the edited copy · {e}"));
                }
            }
        }
        if self.duration > 0 && self.requested != Some(self.cursor) {
            self.requested = Some(self.cursor);
            let mut cmd = ffmpeg();
            let seek = self.cursor.min(self.duration.saturating_sub(50)) as f64 / 1000.;
            cmd.arg("-ss").arg(format!("{seek:.3}")).arg("-i").arg(&self.source)
                .args(["-map", "0:v:0", "-frames:v", "1", "-vf", "scale=512:288:force_original_aspect_ratio=decrease,pad=512:288:(ow-iw)/2:(oh-ih)/2", "-pix_fmt", "rgb24", "-f", "rawvideo", "pipe:1"]);
            self.start(cmd, Task::Frame(self.cursor));
            ctx.request_repaint_after(Duration::from_millis(40));
        }
        Ok(None)
    }

    pub fn show(&mut self, ctx: &Context) -> Outcome {
        match self.poll(ctx) {
            Ok(Some(path)) => return Outcome::Saved(path),
            Err(e) => self.error = e,
            _ => {}
        }
        let mut close = false;
        Modal::new(Id::new("clip editor")).show(ctx, |ui| {
            let width = (ctx.content_rect().width() - 80.).clamp(260., 540.);
            ui.set_width(width);
            ui.horizontal(|ui| {
                ui.heading("Clip editor");
                ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                    close = ui.button("Close").clicked();
                });
            });
            ui.add(
                Label::new(
                    self.source
                        .file_name()
                        .unwrap_or_default()
                        .to_string_lossy(),
                )
                .truncate(),
            );
            let exporting = matches!(self.active, Some((_, Task::Export(_))));
            if self.duration == 0 && self.error.is_empty() {
                ui.label("Opening clip…");
            }
            if self.duration > 0 {
                let height = (ctx.content_rect().height() * 0.32).min(width * 9. / 16.);
                let (area, _) = ui.allocate_exact_size(vec2(width, height), Sense::hover());
                ui.painter().rect_filled(area, 4, design::NAV);
                if let Some(frame) = &self.frame {
                    let rect =
                        Rect::from_center_size(area.center(), vec2(height * 16. / 9., height));
                    ui.painter().image(
                        frame.id(),
                        rect,
                        Rect::from_min_max(Pos2::ZERO, pos2(1., 1.)),
                        Color32::WHITE,
                    );
                }
                ui.add_enabled_ui(!exporting, |ui| {
                    ui.label("Scrub to the start and end of the part you want to remove.");
                    ui.horizontal(|ui| {
                        ui.label("Playhead");
                        ui.monospace(format!("{} / {}", stamp(self.cursor), stamp(self.duration)));
                    });
                    ui.spacing_mut().slider_width = width - 12.;
                    if ui
                        .add(Slider::new(&mut self.cursor, 0..=self.duration).show_value(false))
                        .changed()
                    {
                        ctx.request_repaint();
                    }
                    ui.horizontal_wrapped(|ui| {
                        if ui.button("Set start").clicked() {
                            self.selection.0 = self.cursor;
                        }
                        ui.monospace(stamp(self.selection.0));
                        if ui.button("Set end").clicked() {
                            self.selection.1 = self.cursor;
                        }
                        ui.monospace(stamp(self.selection.1));
                    });
                    let keep = kept_ranges(self.duration, &self.cuts);
                    let mut proposed = self.cuts.clone();
                    proposed.push(self.selection);
                    let next = kept_ranges(self.duration, &proposed);
                    let valid =
                        self.selection.0 < self.selection.1 && !next.is_empty() && next != keep;
                    ui.horizontal(|ui| {
                        if ui
                            .add_enabled(valid, Button::new("Cut selection"))
                            .clicked()
                        {
                            self.cuts.push(self.selection);
                        }
                        if ui
                            .add_enabled(!self.cuts.is_empty(), Button::new("Undo last cut"))
                            .clicked()
                        {
                            self.cuts.pop();
                        }
                    });
                    let (bar, _) = ui.allocate_exact_size(vec2(width, 9.), Sense::hover());
                    ui.painter().rect_filled(bar, 2, design::NAV);
                    for (start, end) in &self.cuts {
                        let x = |ms| bar.left() + width * (ms as f32 / self.duration as f32);
                        ui.painter().rect_filled(
                            Rect::from_min_max(
                                pos2(x(*start), bar.top()),
                                pos2(x(*end), bar.bottom()),
                            ),
                            1,
                            Color32::from_rgb(195, 130, 104),
                        );
                    }
                    ui.horizontal(|ui| {
                        let length = kept_ranges(self.duration, &self.cuts)
                            .iter()
                            .map(|(a, b)| b - a)
                            .sum();
                        ui.label(format!("Edited length  {}", stamp(length)));
                        ui.with_layout(Layout::right_to_left(Align::Center), |ui| {
                            if ui
                                .add_enabled(!self.cuts.is_empty(), Button::new("Save edited copy"))
                                .clicked()
                            {
                                match PartialFile::new(&self.source) {
                                    Ok(file) => {
                                        self.error.clear();
                                        self.start(
                                            export_command(
                                                &self.source,
                                                &file.0,
                                                &kept_ranges(self.duration, &self.cuts),
                                                self.audio,
                                                self.audio_quality,
                                            ),
                                            Task::Export(file),
                                        );
                                        ctx.request_repaint();
                                    }
                                    Err(e) => {
                                        self.error =
                                            format!("Could not create the edited copy · {e}")
                                    }
                                }
                            }
                        });
                    });
                });
            }
            if exporting {
                ui.label("Saving edited copy…");
            }
            if !self.error.is_empty() {
                ui.label(&self.error);
            }
        });
        if close { Outcome::Close } else { Outcome::Open }
    }
}

impl Drop for Editor {
    fn drop(&mut self) {
        self.stop();
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn cuts_can_overlap_and_trim_either_end() {
        assert_eq!(
            kept_ranges(3000, &[(2500, 3000), (1200, 1800), (0, 500), (1000, 1500)]),
            vec![(500, 1000), (1800, 2500)]
        );
    }

    #[test]
    fn middle_cut_joins_the_correct_frames_with_or_without_audio() {
        let folder = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("target")
            .join(format!(
                "editor-test-{}-{}",
                std::process::id(),
                chrono::Utc::now().timestamp_micros()
            ));
        fs::create_dir(&folder).unwrap();
        let ctx = Context::default();
        for (index, (audio, quality)) in [
            (true, AudioQuality::High),
            (true, AudioQuality::Lossless),
            (false, AudioQuality::Lossless),
        ]
        .into_iter()
        .enumerate()
        {
            let source = folder.join(format!("Original {index}.mp4"));
            let mut fixture = ffmpeg();
            fixture.args(["-f", "lavfi", "-i", "color=red:s=64x64:r=10:d=1[r];color=blue:s=64x64:r=10:d=1[b];color=lime:s=64x64:r=10:d=1[g];[r][b][g]concat=n=3:v=1:a=0"]);
            if audio {
                fixture.args(["-f", "lavfi", "-i", "sine=duration=3", "-c:a", "aac"]);
            }
            assert!(
                fixture
                    .args(["-c:v", "libx264"])
                    .arg(&source)
                    .status()
                    .unwrap()
                    .success()
            );
            let original = fs::read(&source).unwrap();
            let mut editor = Editor::open(source.clone(), quality);
            let wait = |editor: &mut Editor| {
                let start = std::time::Instant::now();
                while editor.active.is_some() {
                    let saved = editor.poll(&ctx).unwrap();
                    if saved.is_some() {
                        return saved;
                    }
                    assert!(start.elapsed() < Duration::from_secs(20));
                    thread::sleep(Duration::from_millis(5));
                }
                None
            };
            wait(&mut editor);
            assert_eq!((editor.duration, editor.audio), (3000, audio));
            assert!(editor.frame.is_some());
            let file = PartialFile::new(&source).unwrap();
            let keep = kept_ranges(editor.duration, &[(1000, 2000)]);
            editor.start(
                export_command(&source, &file.0, &keep, editor.audio, editor.audio_quality),
                Task::Export(file),
            );
            let edited = wait(&mut editor).unwrap();
            let output = ffmpeg()
                .arg("-i")
                .arg(&edited)
                .args([
                    "-vf",
                    "scale=1:1",
                    "-pix_fmt",
                    "rgb24",
                    "-f",
                    "rawvideo",
                    "-",
                ])
                .output()
                .unwrap();
            assert!(output.status.success());
            assert_eq!(output.stdout.len(), 20 * 3);
            assert!(
                output.stdout[..30]
                    .as_chunks::<3>()
                    .0
                    .iter()
                    .all(|rgb| rgb[0] > 200 && rgb[1] < 40)
            );
            assert!(
                output.stdout[30..]
                    .as_chunks::<3>()
                    .0
                    .iter()
                    .all(|rgb| rgb[1] > 200 && rgb[0] < 40)
            );
            let mut reopened = Editor::open(edited.clone(), quality);
            wait(&mut reopened);
            assert_eq!(reopened.audio, audio);
            assert!(reopened.duration.abs_diff(2000) < 50);
            assert_eq!(fs::read(&source).unwrap(), original);
            let cancelled = PartialFile::new(&source).unwrap();
            let temp = cancelled.0.clone();
            editor.start(
                export_command(&source, &temp, &keep, audio, quality),
                Task::Export(cancelled),
            );
            drop(editor);
            assert!(!temp.exists());
            fs::remove_file(source).unwrap();
            fs::remove_file(edited).unwrap();
        }
        fs::remove_dir(folder).unwrap();
    }
}
