use crate::{
    audio,
    settings::{AudioQuality, Settings},
};
use std::{
    collections::VecDeque,
    fs,
    io::{self, BufReader, Read, Write},
    os::windows::process::CommandExt,
    path::{Path, PathBuf},
    process::{Command, Stdio},
    sync::{
        Arc, Mutex,
        atomic::{AtomicBool, Ordering},
    },
    thread,
    time::{Duration, Instant},
};

const MEMORY_LIMIT: usize = 1_000_000_000;
const TICKS: f64 = 90_000.0;
const PTS_MASK: u64 = (1 << 33) - 1;
fn elapsed_pts(last: u64, first: u64) -> f64 {
    (last.wrapping_sub(first) & PTS_MASK) as f64 / TICKS
}
pub(crate) fn ffmpeg() -> Command {
    let exe = std::env::current_exe().unwrap();
    let mut file = exe.parent().unwrap().join("media/ffmpeg.exe");
    if !file.exists() {
        file = Path::new(env!("CARGO_MANIFEST_DIR")).join("media/ffmpeg.exe");
    }
    let mut c = Command::new(file);
    c.creation_flags(0x08000000)
        .args(["-hide_banner", "-nostdin", "-loglevel", "error"]);
    c
}
struct Frame {
    pts: u64,
    key: bool,
    bytes: Arc<[u8]>,
    arrived: Instant,
}
#[derive(Default)]
struct Ring {
    frames: VecDeque<Frame>,
    size: usize,
    pat: Vec<u8>,
    pmt: Vec<u8>,
}
impl Ring {
    fn push(&mut self, frame: Frame, seconds: u32) {
        if self.frames.is_empty() && !frame.key {
            return;
        }
        let end = frame.pts;
        self.size += frame.bytes.len();
        self.frames.push_back(frame);
        while self.frames.front().is_some_and(|f| {
            self.size > MEMORY_LIMIT || elapsed_pts(end, f.pts) > seconds as f64 + 0.5
        }) {
            if let Some(f) = self.frames.pop_front() {
                self.size -= f.bytes.len();
            }
            while self.frames.front().is_some_and(|f| !f.key) {
                self.size -= self.frames.pop_front().unwrap().bytes.len();
            }
        }
    }
    fn duration(&self, fps: u32) -> f64 {
        self.frames
            .front()
            .zip(self.frames.back())
            .map_or(0.0, |(a, b)| elapsed_pts(b.pts, a.pts) + 1.0 / fps as f64)
    }
}
#[derive(Clone)]
pub enum State {
    Off,
    Starting,
    Live(String),
    Failed(String),
}
pub struct Runtime {
    ring: Ring,
    pub state: State,
    pub config: Settings,
    audio: Vec<(audio::Source, audio::Audio)>,
    audio_errors: Vec<String>,
    pub busy: bool,
    pub notice: String,
    pub saves: u64,
    generation: u64,
    cancel: Arc<AtomicBool>,
    workers: Vec<thread::JoinHandle<()>>,
}
pub type Engine = Arc<Mutex<Runtime>>;
impl Runtime {
    pub fn configure(&mut self, config: Settings) {
        for (_, ring) in &self.audio {
            ring.lock().unwrap().seconds = config.seconds;
        }
        self.config = config;
    }
    pub fn sound_error(&self) -> Option<String> {
        let mut errors = self.audio_errors.clone();
        for (source, ring) in &self.audio {
            if let Some(error) = &ring.lock().unwrap().failure {
                errors.push(format!("{} interrupted · {error}", source.label()));
            }
        }
        (!errors.is_empty()).then(|| errors.join("\n"))
    }
    pub fn new(config: Settings) -> Engine {
        Arc::new(Mutex::new(Self {
            ring: Ring::default(),
            state: State::Off,
            config,
            audio: Vec::new(),
            audio_errors: Vec::new(),
            busy: false,
            notice: String::new(),
            saves: 0,
            generation: 0,
            cancel: Arc::new(AtomicBool::new(false)),
            workers: Vec::new(),
        }))
    }
    pub fn duration(&self) -> f64 {
        self.ring.duration(self.config.fps)
    }
    pub fn stop(&mut self) {
        self.cancel.store(true, Ordering::Release);
        self.generation += 1;
        self.state = State::Off;
        self.ring = Ring::default();
        self.audio.clear();
        self.audio_errors.clear();
    }
}
pub fn start(engine: &Engine) {
    let (generation, stop, config) = {
        let mut r = engine.lock().unwrap();
        r.stop();
        r.notice.clear();
        r.cancel = Arc::new(AtomicBool::new(false));
        r.state = State::Starting;
        (r.generation, r.cancel.clone(), r.config.clone())
    };
    let e = engine.clone();
    let worker = thread::spawn(move || {
        let mut streams = Vec::new();
        for (source, enabled, device) in [
            (
                audio::Source::Playback,
                config.sound,
                &config.playback_device,
            ),
            (
                audio::Source::Microphone,
                config.microphone,
                &config.mic_device,
            ),
        ] {
            if !enabled {
                continue;
            }
            let ring = audio::empty();
            let stream = audio::start(ring.clone(), source, device.as_deref());
            let mut r = e.lock().unwrap();
            if r.generation != generation {
                return;
            }
            match stream {
                Ok(stream) => {
                    ring.lock().unwrap().seconds = r.config.seconds;
                    streams.push(stream);
                    r.audio.push((source, ring));
                }
                Err(error) => r
                    .audio_errors
                    .push(format!("{} unavailable · {error}", source.label())),
            }
        }
        if stop.load(Ordering::Acquire) {
            return;
        }
        let detail = capture(&e, generation, &stop, &config).unwrap_or_else(|err| err.to_string());
        let mut r = e.lock().unwrap();
        if r.generation == generation {
            r.state = State::Failed(
                if detail.to_lowercase().contains("denied") || detail.contains("error 5") {
                    "Windows denied access to the desktop. Unlock this session and try again."
                        .into()
                } else {
                    format!(
                        "Capture stopped. {}",
                        detail.chars().take(220).collect::<String>()
                    )
                },
            );
            r.ring = Ring::default();
            r.audio.clear();
        }
    });
    track(engine, worker);
}
fn capture(
    e: &Engine,
    generation: u64,
    stop: &AtomicBool,
    config: &Settings,
) -> io::Result<String> {
    use windows_sys::Win32::UI::WindowsAndMessaging::{GetSystemMetrics, SM_CXSCREEN, SM_CYSCREEN};
    let width = unsafe { GetSystemMetrics(SM_CXSCREEN) };
    let height = unsafe { GetSystemMetrics(SM_CYSCREEN) };
    let rate = config.fps.to_string();
    let mut cmd = ffmpeg();
    cmd.args([
        "-f",
        "gdigrab",
        "-framerate",
        &rate,
        "-video_size",
        &format!("{width}x{height}"),
        "-i",
        "desktop",
    ]);
    encode_video(&mut cmd, config);
    let mut child = cmd.stdout(Stdio::piped()).stderr(Stdio::piped()).spawn()?;
    let output = child.stdout.take().unwrap();
    let stderr = child.stderr.take().unwrap();
    let reader_engine = e.clone();
    let reader =
        thread::spawn(move || read_stream(output, &reader_engine, generation, "CPU · system RAM"));
    let log = thread::spawn(move || {
        let mut last = String::new();
        use std::io::BufRead;
        for line in BufReader::new(stderr).lines().map_while(Result::ok) {
            if last.len() < 2048 {
                last.push_str(&line);
                last.push(' ');
            }
        }
        last
    });
    let launch = Instant::now();
    loop {
        if stop.load(Ordering::Acquire)
            || (launch.elapsed() > Duration::from_secs(7)
                && e.lock().unwrap().ring.frames.is_empty())
        {
            let _ = child.kill();
            break;
        }
        if !matches!(child.try_wait(), Ok(None)) {
            break;
        }
        thread::sleep(Duration::from_millis(80));
    }
    let _ = child.wait();
    let _ = reader.join();
    Ok(log.join().unwrap_or_default())
}

fn encode_video(cmd: &mut Command, config: &Settings) {
    let rate = config.fps.to_string();
    cmd.args([
        "-filter_threads",
        "2",
        "-vf",
        &video_filter(config.height),
        "-an",
        "-c:v",
        "libx264",
        "-preset",
        "ultrafast",
        "-tune",
        "zerolatency",
        "-threads",
        "4",
    ]);
    cmd.args([
        "-crf",
        config.video_quality.crf(),
        "-g",
        &rate,
        "-bf",
        "0",
        "-mpegts_start_pid",
        "256",
        "-mpegts_pmt_start_pid",
        "4096",
        "-f",
        "mpegts",
        "-flush_packets",
        "1",
        "-muxdelay",
        "0",
        "pipe:1",
    ]);
}

fn video_filter(height: u32) -> String {
    let height = if height == 0 {
        "trunc(ih/2)*2".into()
    } else {
        height.to_string()
    };
    format!("scale=-2:{height}:flags=bicubic,setsar=1,format=yuv420p")
}
fn track(engine: &Engine, worker: thread::JoinHandle<()>) {
    let mut r = engine.lock().unwrap();
    r.workers.retain(|w| !w.is_finished());
    r.workers.push(worker);
}
pub fn shutdown(engine: &Engine) {
    let workers = {
        let mut r = engine.lock().unwrap();
        r.stop();
        std::mem::take(&mut r.workers)
    };
    for w in workers {
        let _ = w.join();
    }
}
fn read_stream(input: impl Read, engine: &Engine, generation: u64, label: &str) {
    let mut input = BufReader::with_capacity(65536, input);
    let mut packet = [0u8; 188];
    let mut current = Vec::new();
    let mut pts = None;
    let mut key = false;
    while input.read_exact(&mut packet).is_ok() {
        if packet[0] != 0x47 {
            break;
        }
        let pid = (u16::from(packet[1] & 31) << 8) | u16::from(packet[2]);
        if pid == 0 || pid == 4096 {
            let mut r = engine.lock().unwrap();
            if r.generation != generation {
                return;
            }
            if pid == 0 {
                r.ring.pat = packet.to_vec();
            } else {
                r.ring.pmt = packet.to_vec();
            }
            continue;
        }
        if pid != 256 {
            continue;
        }
        if packet[1] & 0x40 != 0 {
            if let Some(t) = pts.take() {
                let mut r = engine.lock().unwrap();
                if r.generation != generation {
                    return;
                }
                let seconds = r.config.seconds;
                r.ring.push(
                    Frame {
                        pts: t,
                        key,
                        bytes: std::mem::take(&mut current).into(),
                        arrived: Instant::now(),
                    },
                    seconds,
                );
                if !r.ring.frames.is_empty() && !matches!(r.state, State::Live(_)) {
                    r.state = State::Live(label.to_owned());
                }
            }
            current.clear();
            let adaptation = packet[3] & 0x20 != 0;
            key = adaptation && packet[4] > 0 && packet[5] & 0x40 != 0;
            let p = if adaptation {
                5 + packet[4] as usize
            } else {
                4
            };
            if p + 14 <= 188 && packet[p..p + 3] == [0, 0, 1] && packet[p + 7] & 0x80 != 0 {
                let b = &packet[p + 9..];
                pts = Some(
                    ((b[0] as u64 & 14) << 29)
                        | ((b[1] as u64) << 22)
                        | ((b[2] as u64 & 254) << 14)
                        | ((b[3] as u64) << 7)
                        | (b[4] as u64 >> 1),
                );
            }
        }
        if pts.is_some() {
            current.extend_from_slice(&packet);
        }
    }
}

struct Clip {
    packets: Vec<Arc<[u8]>>,
    headers: Vec<u8>,
    sound: Vec<audio::AudioClip>,
    folder: PathBuf,
    duration: f64,
    audio_quality: AudioQuality,
}
pub fn save(engine: &Engine) {
    let clip = {
        let mut r = engine.lock().unwrap();
        if r.busy {
            r.notice = "A clip is already being saved.".into();
            return;
        }
        if !matches!(r.state, State::Live(_)) || r.ring.frames.is_empty() {
            r.notice = "Enable the replay buffer and give it a moment to fill.".into();
            return;
        }
        let last = r.ring.frames.back().unwrap();
        if last.arrived.elapsed() > Duration::from_secs(3) {
            r.notice = "Waiting for fresh frames from the display.".into();
            return;
        }
        let duration = r.duration();
        let sound = r
            .audio
            .iter()
            .map(|(_, ring)| ring.lock().unwrap().snapshot(last.arrived, duration))
            .collect();
        let snapshot = Clip {
            packets: r.ring.frames.iter().map(|f| f.bytes.clone()).collect(),
            headers: [&r.ring.pat[..], &r.ring.pmt[..]].concat(),
            sound,
            folder: r.config.folder.clone(),
            duration,
            audio_quality: r.config.audio_quality,
        };
        r.busy = true;
        r.notice = "Saving clip…".into();
        snapshot
    };
    let e = engine.clone();
    let worker = thread::spawn(move || {
        let result = export(clip);
        let mut r = e.lock().unwrap();
        r.busy = false;
        let confirmation = match result {
            Ok(()) => {
                r.saves += 1;
                r.notice = "Clip saved to your library.".into();
                Some((r.config.save_ping, r.config.save_overlay))
            }
            Err(err) => {
                r.notice = format!("Couldn’t save clip · {err}");
                None
            }
        };
        drop(r);
        if let Some((sound, overlay)) = confirmation {
            if sound {
                crate::desktop::save_ping();
            }
            if overlay {
                crate::overlay::show();
            }
        }
    });
    track(engine, worker);
}
fn export(clip: Clip) -> Result<(), String> {
    fs::create_dir_all(&clip.folder).map_err(|e| e.to_string())?;
    let now = chrono::Local::now();
    let name = format!(
        "Replay {} · {:.0}s",
        now.format("%Y-%m-%d %H-%M-%S%.3f"),
        clip.duration
    );
    let output = clip.folder.join(format!("{name}.mp4"));
    let temp = clip.folder.join(format!(
        ".cutline-{}-{}",
        std::process::id(),
        now.timestamp_micros()
    ));
    fs::create_dir(&temp).map_err(|e| e.to_string())?;
    let partial = temp.join("clip.mp4");
    let wavs: Vec<_> = (0..clip.sound.len())
        .map(|i| temp.join(format!("sound-{i}.wav")))
        .collect();
    let result = (|| {
        let mut cmd = ffmpeg();
        cmd.args(["-f", "mpegts", "-i", "pipe:0"]);
        for (sound, path) in clip.sound.iter().zip(&wavs) {
            sound.write(path).map_err(|e| e.to_string())?;
            cmd.arg("-i").arg(path);
        }
        cmd.args(["-map", "0:v:0"]);
        if wavs.len() == 2 {
            cmd.args([
                "-filter_complex",
                "[1:a][2:a]amix=inputs=2:normalize=0,alimiter=limit=0.96:level=0:latency=1[mix]",
                "-map",
                "[mix]",
            ]);
        } else if wavs.len() == 1 {
            cmd.args(["-map", "1:a:0"]);
        }
        if !wavs.is_empty() {
            cmd.args(clip.audio_quality.encoder_args());
        }
        cmd.args(["-c:v", "copy", "-movflags", "+faststart"])
            .arg(&partial);
        let mut child = cmd
            .stdin(Stdio::piped())
            .stdout(Stdio::null())
            .stderr(Stdio::piped())
            .spawn()
            .map_err(|e| e.to_string())?;
        let mut pipe = io::BufWriter::new(child.stdin.take().unwrap());
        let write = (|| -> io::Result<()> {
            pipe.write_all(&clip.headers)?;
            for frame in clip.packets {
                pipe.write_all(&frame)?;
            }
            pipe.flush()
        })();
        drop(pipe);
        let out = child.wait_with_output().map_err(|e| e.to_string())?;
        if !out.status.success() {
            return Err(String::from_utf8_lossy(&out.stderr)
                .trim()
                .chars()
                .take(240)
                .collect());
        }
        write.map_err(|e| e.to_string())?;
        fs::rename(&partial, &output).map_err(|e| e.to_string())
    })();
    for path in wavs {
        let _ = fs::remove_file(path);
    }
    let _ = fs::remove_file(&partial);
    let _ = fs::remove_dir(&temp);
    result
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn quality_presets_retain_more_detail_on_the_same_moving_picture() {
        use crate::settings::VideoQuality;
        let source = "testsrc2=size=1280x720:rate=60:duration=1";
        let mut previous_psnr = 0.0;
        for quality in [
            VideoQuality::Compact,
            VideoQuality::High,
            VideoQuality::Maximum,
        ] {
            let mut encode = ffmpeg();
            encode.args(["-f", "lavfi", "-i", source]);
            encode_video(
                &mut encode,
                &Settings {
                    video_quality: quality,
                    ..Default::default()
                },
            );
            let encoded = encode.output().unwrap();
            assert!(
                encoded.status.success(),
                "{}",
                String::from_utf8_lossy(&encoded.stderr)
            );
            let mut compare = ffmpeg()
                .args([
                    "-loglevel",
                    "info",
                    "-f",
                    "mpegts",
                    "-i",
                    "pipe:0",
                    "-f",
                    "lavfi",
                    "-i",
                    source,
                    "-filter_complex",
                    "[0:v]setpts=PTS-STARTPTS[clip];[clip][1:v]psnr",
                    "-an",
                    "-f",
                    "null",
                    "-",
                ])
                .stdin(Stdio::piped())
                .stderr(Stdio::piped())
                .spawn()
                .unwrap();
            compare
                .stdin
                .take()
                .unwrap()
                .write_all(&encoded.stdout)
                .unwrap();
            let result = compare.wait_with_output().unwrap();
            let log = String::from_utf8_lossy(&result.stderr);
            assert!(result.status.success(), "{log}");
            let psnr: f64 = log
                .split("average:")
                .last()
                .unwrap()
                .split_whitespace()
                .next()
                .unwrap()
                .parse()
                .unwrap();
            println!("{}: {psnr:.2} dB", quality.label());
            assert!(psnr > previous_psnr, "{log}");
            previous_psnr = psnr;
        }
    }
    #[test]
    fn resolution_presets_preserve_the_display_shape() {
        for &height in crate::settings::HEIGHTS {
            let result = ffmpeg()
                .args([
                    "-f",
                    "lavfi",
                    "-i",
                    "testsrc2=s=1440x1080",
                    "-vf",
                    &video_filter(height),
                    "-frames:v",
                    "1",
                    "-f",
                    "framehash",
                    "-",
                ])
                .output()
                .unwrap();
            assert!(
                result.status.success(),
                "{}",
                String::from_utf8_lossy(&result.stderr)
            );
            let h = if height == 0 { 1080 } else { height };
            let width = h * 4 / 3;
            assert!(
                String::from_utf8_lossy(&result.stdout)
                    .contains(&format!("#dimensions 0: {width}x{h}"))
            );
        }
    }
    #[test]
    fn recent_frames_and_audio_export_as_one_playable_clip() {
        for quality in [AudioQuality::High, AudioQuality::Lossless] {
            verify_clip_export(quality);
        }
    }
    fn verify_clip_export(quality: AudioQuality) {
        let dir = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("target")
            .join(format!(
                "clip-test-{}-{}",
                std::process::id(),
                chrono::Utc::now().timestamp_micros()
            ));
        let engine = Runtime::new(Settings {
            seconds: 5,
            fps: 30,
            folder: dir.clone(),
            audio_quality: quality,
            save_ping: false,
            save_overlay: false,
            ..Default::default()
        });
        let mut fixture = ffmpeg();
        fixture.args([
            "-f",
            "lavfi",
            "-i",
            "testsrc2=size=160x90:rate=30:duration=9.3",
        ]);
        encode_video(&mut fixture, &engine.lock().unwrap().config);
        let fixture = fixture.output().unwrap();
        assert!(fixture.status.success());
        read_stream(&fixture.stdout[..], &engine, 0, "Test input");
        let count = {
            let mut r = engine.lock().unwrap();
            assert!(matches!(r.state, State::Live(_)));
            assert!((4.5..5.6).contains(&r.duration()));
            assert!(r.ring.frames.front().unwrap().key);
            let end = r.ring.frames.back().unwrap().arrived;
            for source in [audio::Source::Playback, audio::Source::Microphone] {
                let ring = audio::empty();
                if source == audio::Source::Playback {
                    ring.lock().unwrap().test_tone(end);
                }
                r.audio.push((source, ring));
            }
            r.ring.frames.len()
        };
        // Send a hotkey message to our registered listener without typing into another app.
        let listener =
            crate::desktop::Shortcut::bind(0x87, engine.clone(), eframe::egui::Context::default())
                .unwrap();
        assert!(listener.dispatch_test_message());
        drop(listener);
        shutdown(&engine);
        {
            let runtime = engine.lock().unwrap();
            assert_eq!(runtime.saves, 1, "{}", runtime.notice);
        }
        let files: Vec<_> = fs::read_dir(&dir)
            .unwrap()
            .map(|f| f.unwrap().path())
            .collect();
        assert_eq!(files.len(), 1);
        // An enabled but silent microphone should leave the playback tone at its original level.
        let tone = ffmpeg()
            .arg("-i")
            .arg(&files[0])
            .args(["-ss", "1", "-t", "1", "-map", "0:a:0", "-f", "s16le", "-"])
            .output()
            .unwrap();
        assert!(tone.status.success());
        assert_eq!(tone.stdout.len(), 48_000 * 2 * 2);
        let energy: f64 = tone
            .stdout
            .as_chunks::<2>()
            .0
            .iter()
            .map(|b| f64::from(i16::from_le_bytes([b[0], b[1]])).powi(2))
            .sum();
        let rms = (energy / 96_000.0).sqrt();
        assert!((6000.0..6700.0).contains(&rms), "Playback RMS {rms}");
        let preview = crate::preview::decode(&files[0], true);
        assert_eq!(preview.len(), 8);
        assert_eq!(crate::preview::decode(&files[0], false).len(), 1);
        assert_ne!(preview[0].pixels, preview[1].pixels);
        let decode = ffmpeg()
            .arg("-i")
            .arg(&files[0])
            .args([
                "-map",
                "0:v:0",
                "-map",
                "0:a:0",
                "-progress",
                "pipe:1",
                "-f",
                "null",
                "-",
            ])
            .output()
            .unwrap();
        assert!(
            decode.status.success(),
            "{}",
            String::from_utf8_lossy(&decode.stderr)
        );
        let progress = String::from_utf8_lossy(&decode.stdout);
        assert!(
            progress
                .lines()
                .any(|line| line.trim() == format!("frame={count}")),
            "{progress}"
        );
        println!(
            "Verified {count} frames at 30 fps with {} and an empty scratch folder after export.",
            quality.label()
        );
        fs::remove_file(&files[0]).unwrap();
        fs::remove_dir(dir).unwrap();
    }
}
