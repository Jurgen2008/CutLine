# Third-party components

## Rust dependencies

Cutline uses eframe/egui, CPAL, image, serde, serde_json, chrono, raw-window-handle, windows-sys and their dependencies. `Cargo.lock` records the dependency versions. These components retain their respective upstream licenses; the license of Cutline does not replace theirs.

## FFmpeg

Cutline launches FFmpeg as a separate command-line process. No FFmpeg executable or FFmpeg implementation source is included in this source repository.

Original validation used Gyan's FFmpeg 9.0.2 full Windows build, which is distributed under GPLv3. `media/COPYING.txt` contains the GPLv3 license text for reference. If you choose another FFmpeg build, check its actual configuration and applicable license.

- FFmpeg project and source: <https://ffmpeg.org/> and <https://git.ffmpeg.org/ffmpeg.git>
- Original binary build provider: <https://www.gyan.dev/ffmpeg/builds/>
- FFmpeg licensing information: <https://ffmpeg.org/legal.html>

If you distribute FFmpeg with Cutline, retain the applicable license and notices and satisfy the corresponding-source requirements for the exact FFmpeg build, including the libraries and modifications used to produce it. A link to a generic upstream source tree is not a substitute for identifying and providing the corresponding build sources. Do not relabel FFmpeg as Cutline's own code or license third-party components under incompatible terms.
